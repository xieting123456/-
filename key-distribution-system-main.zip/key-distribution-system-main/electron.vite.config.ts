import { resolve } from 'path'
import { defineConfig, externalizeDepsPlugin } from 'electron-vite'
import { viteMockServe } from 'vite-plugin-mock'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  main: {
    plugins: [externalizeDepsPlugin()]
  },
  preload: {
    plugins: [externalizeDepsPlugin()]
  },
  renderer: {
    resolve: {
      alias: {
        '@renderer': resolve('src/renderer/src')
      }
    },
    plugins: [
      vue(),
      viteMockServe({
        mockPath: 'mock' //解析根目录下的mock文件夹
      })
    ],
    server: {
      proxy: {
        '/dm/v1': {
          // 匹配请求路径，
          // target: 'http://192.168.72.23:39696', // 代理的目标地址
          // 开发模式，默认的127.0.0.1,开启后代理服务会把origin修改为目标地址
          changeOrigin: true,
          secure: true, // 是否https接口
          // ws: true, // 是否代理websockets

          // 路径重写，**** 如果你的后端有统一前缀(如:/api)，就不开启；没有就开启
          //简单来说，就是是否改路径 加某些东西
          rewrite: (path) => path.replace(/^\/api/, '')
        }
      }
    },
    // configureWebpack: {
    //   //关闭 webpack 的性能提示
    //   performance: {
    //     hints: false
    //   }
    // }
  }
})
