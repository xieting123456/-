var api = (window.baseURL = 'http://localhost:39696')
export default api
