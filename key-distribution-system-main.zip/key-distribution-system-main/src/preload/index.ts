import { contextBridge, ipcRenderer } from 'electron'
import { electronAPI } from '@electron-toolkit/preload'

// Custom APIs for renderer
const api = {
  closeLoading: () => {
    ipcRenderer.send('close-loading', {
      isClose: true
    })
  },
  showHomePage: (res) => {
    ipcRenderer.send('show-HomePage', res)
  },
  // 窗口最小化
  windowMin: () => {
    ipcRenderer.send('window-min')
  },

  windowClose: () => {
    ipcRenderer.send('window-close')
  },
  incrementNumber: (callback) => {
    ipcRenderer.on('closeAllWindow', callback)
  },
  serverStart: (callback) => {
    ipcRenderer.on('serverStart', callback)
  },
  serverClose: (callback) => {
    ipcRenderer.on('serverClose', callback)
  }
}

// Use `contextBridge` APIs to expose Electron APIs to
// renderer only if context isolation is enabled, otherwise
// just add to the DOM global.
if (process.contextIsolated) {
  try {
    contextBridge.exposeInMainWorld('electron', electronAPI)
    contextBridge.exposeInMainWorld('api', api)
  } catch (error) {
    console.error(error)
  }
} else {
  // @ts-ignore (define in dts)
  window.electron = electronAPI
  // @ts-ignore (define in dts)
  window.api = api
}
