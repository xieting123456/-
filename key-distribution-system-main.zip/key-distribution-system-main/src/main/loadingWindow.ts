// import { BrowserWindow, screen } from 'electron'
// import path from 'path'
// export var loading
// function loadingWindow(cb) {
//   var size = screen.getPrimaryDisplay().workAreaSize
//   // Create the browser window.
//   loading = new BrowserWindow({
//     width: 430,
//     height: 328,
//     x: Math.round(size.width / 2 - 430 / 2),
//     y: Math.round(size.height / 2 - 328 / 2),
//     alwaysOnTop: false,
//     modal: true,
//     frame: false,
//     darkTheme: true,
//     resizable: false,
//     minimizable: false,
//     maximizable: false,
//     transparent: true,
//     center: true,
//     webPreferences: {
//       devTools: true,
//       preload: path.resolve(__dirname, '../preload/index.js'),
//       sandbox: false, //可以使得在预加载使用node模块
//       webviewTag: true,
//       nodeIntegration: true, //可以使得在预加载使用node模块
//       contextIsolation: false,
//       webSecurity: false
//     }
//     // ...(process.platform === 'linux' ? { icon } : {})
//   })
//   // var size = screen.getPrimaryDisplay().workAreaSize
//   //   const loadingX = parseInt((size.width / 2 - loading.getSize()[0] / 2).toString())
//   //   const loadingY = parseInt((size.height / 2 - loading.getSize()[1] / 2).toString())
//   //   loading.setPosition(loadingX, loadingY, true)
//   // if (is.dev && process.env['ELECTRON_RENDERER_URL']) {
//   //   // 开发环境
//   //   // loading.loadURL(process.env['ELECTRON_RENDERER_URL'])
//   //   loading.loadFile(path.resolve(__dirname, '../renderer/loading.html'))
//   // } else {
//   //   // 生产环境
//   //   loading.loadFile(path.resolve(__dirname, '../renderer/loading.html'))
//   // }

//   loading.once('show', cb)

//   loading.loadFile(path.resolve(__dirname, '../../resources/loading.html'))
//   // Menu.setApplicationMenu(null)
//   // // 窗口创建监听
//   // loading.once('show', cb)
//   loading.once('ready-to-show', () => {
//     loading.show()
//   })

//   loading.on('close', function (e) {
//     console.log('我是加载进程', e)
//   })
// }

// export default loadingWindow
