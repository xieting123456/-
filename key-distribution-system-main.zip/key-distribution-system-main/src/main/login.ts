// import { BrowserWindow, ipcMain, screen, app } from 'electron'
// import path from 'path'
// import { is } from '@electron-toolkit/utils'
// import { loading } from './loadingWindow'

// export var loginWindow

// function LoginWindow() {
//   var size = screen.getPrimaryDisplay().workAreaSize
//   loginWindow = new BrowserWindow({
//     width: 1000,
//     height: 600,
//     x: Math.round(size.width / 2 - 1000 / 2),
//     y: Math.round(size.height / 2 - 1000 / 2),
//     alwaysOnTop: false,
//     modal: true,
//     // minimizable: false,
//     // maximizable: false,
//     darkTheme: true,
//     resizable: false,
//     transparent: true,
//     center: true,
//     show: false,
//     frame: false,
//     webPreferences: {
//       devTools: true,
//       preload: path.resolve(__dirname, '../preload/index.js'),
//       sandbox: false, //可以使得在预加载使用node模块
//       webviewTag: true,
//       nodeIntegration: true, //可以使得在预加载使用node模块
//       contextIsolation: false,
//       webSecurity: false
//     }
//   })
//   // Menu.setApplicationMenu(null)
//   if (is.dev && process.env['ELECTRON_RENDERER_URL']) {
//     // 开发环境
//     loginWindow.loadURL(process.env['ELECTRON_RENDERER_URL'])
//   } else {
//     // 生产环境
//     loginWindow.loadFile(path.resolve(__dirname, '../renderer/index.html'))
//   }

//   loginWindow.on('ready-to-show', () => {
//     loginWindow.show()
//   })

//   loginWindow.on('close', function (e) {
//     mainWindow.webContents.send('closeAllWindow')

//     console.log('我是主进程', BrowserWindow.getAllWindows().length)
//   })
//   // ready-to-show 事件
//   //渲染进程首次渲染页面触发该事件, 仅触发一次与 show 配置结合使用:
//   // loginWindow.once('ready-to-show', () => {
//   // 等待加载完毕再展示
//   ipcMain.on('close-loading', (e, res) => {
//     console.log(e)
//     if (res.isClose) {
//       loading.hide()
//       // loading.close()
//       loginWindow.show()
//       loginWindow.focus()
//     }
//   })

//   //接收最小化命令
//   ipcMain.on('window-min', function () {
//     loginWindow.minimize()
//   })

//   //接收关闭命令
//   ipcMain.on('window-close', function () {
//     app.quit()
//   })

//   ipcMain.on('show-HomePage', (e, res) => {
//     console.log(e, res)
//     // 我发现有登录
//     loginWindow.setSize(1000, 600)
//     const loginWindowX = Math.round(size.width / 2 - loginWindow.getSize()[0] / 2)
//     const loginWindowY = Math.round(size.height / 2 - loginWindow.getSize()[1] / 2)
//     loginWindow.setPosition(loginWindowX, loginWindowY, true)
//   })
// }
// //   //接收关闭命令
// // export var c= ipcMain.on('window-close', function () {
// //     app.quit()
// //   })
// export default LoginWindow
