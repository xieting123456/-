import { BrowserWindow, ipcMain, screen, app } from 'electron'
import path from 'path'
import { is } from '@electron-toolkit/utils'
import { getExePath } from './getBaseUrl.js'
import logger from '../../log.js'

export var mainWindow
function createWindow() {
  var size = screen.getPrimaryDisplay().workAreaSize
  mainWindow = new BrowserWindow({
    width: 1000,
    height: 600,
    x: Math.round(size.width / 2 - 1000 / 2),
    y: Math.round(size.height / 2 - 1000 / 2),
    alwaysOnTop: false,
    modal: true,
    // minimizable: false,
    // maximizable: false,
    darkTheme: true,
    resizable: false,
    transparent: true,
    center: true,
    show: false,
    frame: false,
    webPreferences: {
      devTools: true,
      preload: path.resolve(__dirname, '../preload/index.js'),
      sandbox: false, //可以使得在预加载使用node模块
      webviewTag: true,
      nodeIntegration: true, //可以使得在预加载使用node模块
      contextIsolation: false,
      webSecurity: false
    }
  })
  if (is.dev && process.env['ELECTRON_RENDERER_URL']) {
    // 开发环境
    mainWindow.loadURL(process.env['ELECTRON_RENDERER_URL'])
  } else {
    // 生产环境
    mainWindow.loadFile(path.resolve(__dirname, '../renderer/index.html'))
  }
  // mainWindow.setAspectRatio(1)

  // 当页面渲染完成后，该事件会被触发。然后调用show()，就可以显示页面了。
  // mainWindow.on('ready-to-show', () => {
  //   loading.hide()
  //   loading.close()
  //   mainWindow.show()
  // })

  mainWindow.once('ready-to-show', () => {
    mainWindow.show()
    startServer()
    // let appPath = app.getPath('server')
    // 获取上一层的目录 app 是当前目录名称 须要给去掉
    // let path = appPath.replace(/\\app\\studio.exe/, '')
    // console.log(appPath)
  })

  mainWindow.on('close', function () {
    stopServer()
    mainWindow.webContents.send('closeAllWindow')
  })

  ipcMain.on('close-loading', (e, res) => {
    console.log(e, res)
    if (res.isClose) {
      // loading.hide()
      mainWindow.show()
      mainWindow.focus()
    }
  })

  //接收最小化命令
  ipcMain.on('window-min', function () {
    mainWindow.minimize()
  })

  //接收关闭命令
  ipcMain.on('window-close', function () {
    mainWindow.webContents.send('closeAllWindow')
    app.quit()
  })

  ipcMain.on('show-HomePage', () => {
    // 我发现有登录
    mainWindow.setSize(1000, 600)
    const mainWindowX = Math.round(size.width / 2 - mainWindow.getSize()[0] / 2)
    const mainWindowY = Math.round(size.height / 2 - mainWindow.getSize()[1] / 2)
    mainWindow.setPosition(mainWindowX, mainWindowY, true)
  })

  app.on('render-process-gone', (event, webContents, details) => {
    mainWindow.webContents.send('closeAllWindow')
    logger.warn('渲染器进程意外消失时触发', event, webContents, details)
    app.quit()
  })
  app.on('child-process-gone', (event, details) => {
    mainWindow.webContents.send('closeAllWindow')
    logger.warn('子进程意外消失时触发', event, details)
    app.quit()
  })

  var serverProcess
  //启动本项目中的服务器
  async function startServer() {
    let cmdStr = 'dm.exe' // 要运行的命令
    var exec = require('child_process').exec
    var serverPath = is.dev ? 'resources/server' : getExePath() // 注意开发环境和线上环境的路径不同；
    logger.warn('路径:' + getExePath())
    runExec(cmdStr)
    function runExec(cmdStr) {
      serverProcess = exec(cmdStr, { cwd: serverPath })
      //exec 函数 第一个参数是要执行的命令，第二个函数是配置选项，第三个参数是回调函数，配置项中常用到 子进程的工作目录
      // serverProcess = require('child_process').exec(cmdStr, { cwd: serverPath })
      serverProcess.stdout.on('data', function (data) {
        mainWindow.webContents.send('serverStart')
        // logger.warn('打印正常的后台可执行程序输出 stdout:' + data) // 这样就会输出日志到文件夹中了
        logger.warn('打印正常的后台可执行程序输出 stdout:' + data)
        console.log('打印正常的后台可执行程序输出 stdout:' + data) // 打印正常的后台可执行程序输出
      })

      serverProcess.stderr.on('data', function (data) {
        console.log('/打印错误的后台可执行程序输出' + data) //打印错误的后台可执行程序输出
        logger.warn('打印正常的后台可执行程序输出 stdout:' + data)
      })

      serverProcess.on('close', function (code) {
        console.log('退出之后的输出:' + code) // 退出之后的输出
        logger.warn('打印正常的后台可执行程序输出 stdout:' + code)
      })
    }
  }

  // 关闭项目中的所有进程，主要是为了关闭刚刚启动的服务器进程。
  function stopServer() {
    const kill = require('tree-kill')
    //  tree-kill是一个插件，需要安装，在项目中已经用 yarn add tree-kill 命令安装。
    kill(serverProcess.pid)
    mainWindow.webContents.send('serverClose')
    logger.warn('关闭所有进程!')
  }
}

export default createWindow
