const { app, Menu, Tray } = require('electron')
import { mainWindow } from './mainWindow'

const path = require('path')
let tray = null
const trayFun = () => {
  tray = new Tray(path.resolve(__dirname, '../../resources/logo.png'))

  const contextMenu = Menu.buildFromTemplate([
    {
      label: '打开',
      click: () => {
        mainWindow.show()
      }
    },
    {
      label: '退出',
      click: () => {
        if (process.platform !== 'darwin') {
          mainWindow.webContents.send('closeAllWindow')
          app.quit()
        }
      }
    }
  ])
  tray.setToolTip('离线密钥分发系统')
  tray.setContextMenu(contextMenu)
  tray.addListener('double-click', () => {
    mainWindow.show()
 
  })
}
export { trayFun }
