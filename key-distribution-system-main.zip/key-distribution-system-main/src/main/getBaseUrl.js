import path from 'path'
const fs = require('fs')
import { app } from 'electron'
import logger from '../../log.js'

export function getSystem() {
  //这是mac系统
  if (process.platform == 'darwin') {
    return 1
  }
  //这是windows系统
  if (process.platform == 'win32') {
    return 2
  }
  //这是linux系统
  if (process.platform == 'linux') {
    return 3
  }
}
/**
 *
 * @returns 获取安装路径
 */
export function getExePath() {
  // return path.dirname("C:");
  return path.dirname(app.getPath('exe')) + `\\server`
}
/**
 *
 * @returns 获取配置文件路径
 */
export function getConfigPath() {
  //   var a = getExePath().split('dist').join('')

  if (getSystem() === 1) {
    return getExePath() + '/dm.exe'
  } else {
    return getExePath() + '\\dm.exe'
  }
}
/**
 * 读取配置文件
 */
// export function readConfig() {
//     return new Promise((res, rej) => {
//       console.log(getConfigPath())
//   })
// }
