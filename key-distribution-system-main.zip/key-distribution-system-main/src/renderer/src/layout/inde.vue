<template>
  <div class="common-layout">
    <el-container>
      <div class="loding" v-show="!show">
        <el-progress :percentage="percentage" :format="format" :color="customColor"></el-progress>
        <div> 离线密钥分发系统...</div>
      </div>
      <el-header v-if="show">
        <div class="elHeaderTop" style="-webkit-app-region: drag;-webkit-user-select: none;">
          <div class="imgLogo">
          </div>
          <el-dropdown style="-webkit-app-region: no-drag;" trigger="click" class="elDropdown">
            <span class="el-dropdown-link">
              <el-icon class="el-icon--right">
                <CaretBottom />
              </el-icon>
            </span>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item>
                  <span class="pinterClass" @click="loginOut">退出登录</span></el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>

          <div class="elHeaderTopIcon" style="-webkit-app-region: no-drag;">
            <el-icon class="iconTop" @click="windowMin">
              <Minus></Minus>
            </el-icon>
            <el-icon class="iconTop" @click="windowClose">
              <Close></Close>
            </el-icon>
          </div>
        </div>
        <div class="elHeaderBottom">
          <el-row :gutter="20">
            <el-col :span="3" v-for="item,index in router" :key="index" style="padding: 0;">
              <router-link :to="item.path" :name="item.name">
                <div v-if="!item.meta.hidden" :class="$route.path==item.path?'c':'x'">
                  {{ item.meta.name }}
                </div>
              </router-link>
            </el-col>
          </el-row>
        </div>
      </el-header>
      <el-main v-if="show">
        <router-view></router-view>
      </el-main>
    </el-container>
  </div>
</template>
<script>
import { ElMessage } from 'element-plus'
import { useCounterStore } from '../store/index.js'
import { ecLogout, qkcLogout } from '@renderer/api/loginOut.js'
import { storeToRefs } from 'pinia'
import loding from './loding.vue'
export default {
  name: 'layout',
  components: loding,
  data() {
    return {
      show: false,
      percentage: 20,
      customColor: '#409eff',
      router: [],
      activeName: 'first',
    }
  },
  created() {
    const routerLayout = useCounterStore();
    const { layOutRouter } = storeToRefs(routerLayout);
    this.router = layOutRouter
    // 如果分配标识存在
    // if (localStorage.getItem('allocation')) {
    //   if (localStorage.getItem('allocation') == 1) {
    //     for (var a = 0; a < this.router.length; a++) {
    //       if (this.router[a].path === '/KeyCenterHomePage') {
    //         this.router[a].meta.hidden = false
    //       }
    //       if (this.router[a].path === "/login") {
    //         this.router[a].meta.hidden = true
    //       }
    //     }
    //     routerLayout.setLayOutRouter(this.router)
    //   } else if (localStorage.getItem('allocation') == 2) {
    //     // 长度等于2展示首页和任务列表
    //     for (var a = 0; a < this.router.length; a++) {
    //       if (this.router[a].path === "/allocationList") {
    //         this.router[a].meta.hidden = false
    //       }
    //       if (this.router[a].path === '/KeyCenterHomePage') {
    //         this.router[a].meta.hidden = false
    //       }
    //       if (this.router[a].path === "/login") {
    //         this.router[a].meta.hidden = true
    //       }
    //     }
    //     routerLayout.setLayOutRouter(this.router)
    //   }
    // }
  },
  mounted() {
    var a = setInterval(() => {
      this.percentage += 10;
      if (this.percentage > 100) {
        this.percentage = 100;
        this.show = true
        clearInterval(a);
        a = null
        return
      }
    }, 200)
  },
  methods: {
    format(percentage) {
      return percentage === 100 ? '' : ``;
    },
    windowMin() {
      window.api.windowMin()
    },
    windowClose() {
      window.api.windowClose()
    },
    async loginOut() {
      try {
        if (localStorage.getItem("routingState")) {
          if (localStorage.getItem("routingState") == 'distribute') {
            // 退出加密卡
            await ecLogout()
            ElMessage({
              message: '加密卡已退出登录',
              type: 'success',
            })
          } else if (localStorage.getItem("routingState") == 'allocation') {
            // 退出密钥中心
            await qkcLogout()
            ElMessage({
              message: '密钥中心已退出登录',
              type: 'success',
            })
          }
        }
      } catch (err) {
      }
      localStorage.removeItem('distribute')
      localStorage.removeItem('routingState')
      localStorage.removeItem('allocation')
      localStorage.removeItem('synchronization')
      const routerLayout = useCounterStore();
      const { layOutRouter } = storeToRefs(routerLayout);
      routerLayout.setLayOutRouter()
      this.$router.push('/login')
    }
  }
}
</script>
<style  lang="less" scoped>
.v-enter-active,
.v-leave-active {
  transition: opacity 0.5s ease;
}

.v-enter-from,
.v-leave-to {
  opacity: 0;
}
::v-deep(.el-header) {
  position: relative;
}
.iconTop {
  margin-left: 20px;
  color: #fff;
  font-size: 20px;
}
.imgLogo {
  position: absolute;
  width: 150px;
  height: 22px;
  background: url('@renderer/assets/logo.png') no-repeat;
  background-size: 100%;
  margin-top: 10px;
}
.elHeaderTop {
  position: relative;
  width: 100%;
  height: 35px;
  line-height: 35px;
  right: 0px;
  .elHeaderTopIcon {
    float: right;
    margin-top: 10px;
  }
}
.elHeaderBottom {
  position: absolute;
  bottom: 0px;
  width: 100%;
  height: 32px;
  line-height: 32px;
  text-align: center;
  margin-left: 10px;
}

.c {
  background-color: #d3e0fd;
  border-radius: 4px 4px 0 0;
  color: black;
}
.x {
  color: #aad4f6;
}
.el-icon--right {
  color: #aad4f6;
}
.elDropdown {
  position: absolute;
  left: 17.5%;
  top: 31%;
}
.loding {
  position: relative;
  text-align: center;
  margin: 0 auto;
  top: 200px;
  .el-progress {
    width: 400px;
    height: 20px;
  }
  div {
    color: black;
    font-size: 24px;
  }
}
</style>