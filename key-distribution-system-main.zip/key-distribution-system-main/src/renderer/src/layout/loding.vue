<template>
  <div class="box">
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
  </div>
</template>
<style>
* {
  padding: 0;
  margin: 0;
}

.box {
  position: relative;
  width: 200px;
  height: 200px;
  margin: 50px auto;
  background-color: antiquewhite;
}

.box > div {
  position: absolute;
  background-color: aqua;
  border-radius: 50%;
  width: 40px;
  height: 40px;
  margin: 0;
  padding: 0;
  animation: box infinite both 2s;
}

.box > div:nth-child(1) {
  top: 20px;
  left: 40px;
}

.box > div:nth-child(2) {
  top: 0px;
  left: 80px;
  animation-delay: 0.25s;
}

.box > div:nth-child(3) {
  top: 20px;
  left: 120px;
  animation-delay: 0.5s;
}

.box > div:nth-child(4) {
  top: 60px;
  left: 140px;
  animation-delay: 0.75s;
}

.box > div:nth-child(5) {
  top: 100px;
  left: 120px;
  animation-delay: 1s;
}

.box > div:nth-child(6) {
  top: 120px;
  left: 80px;
  animation-delay: 1.25s;
}

.box > div:nth-child(7) {
  top: 100px;
  left: 40px;
  animation-delay: 1.5s;
}

.box > div:nth-child(8) {
  top: 60px;
  left: 20px;
  animation-delay: 1.75s;
}

.box > div:nth-child(9) {
  top: 160px;
  left: 20px;
  animation-delay: 0s;
}

.box > div:nth-child(10) {
  top: 160px;
  left: 60px;
  animation-delay: 0.5s;
}

.box > div:nth-child(11) {
  top: 160px;
  left: 100px;
  animation-delay: 1s;
}

.box > div:nth-child(12) {
  top: 160px;
  left: 140px;
  animation-delay: 1.5s;
}

@keyframes box {
  0% {
    -webkit-transform: scale(1);
    transform: scale(1);
  }

  50% {
    -webkit-transform: scale(0.5);
    transform: scale(0.5);
    opacity: 0.5;
  }

  100% {
    -webkit-transform: scale(1);
    transform: scale(1);
    opacity: 1;
  }
}
</style>