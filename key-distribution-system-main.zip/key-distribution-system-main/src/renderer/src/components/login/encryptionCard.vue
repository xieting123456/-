<template>
  <div class="login_container">
    <div class="grid">
      <img @click="goBack" style="margin-top: 5px;" src="@renderer/assets/loginImg/goBack.png" alt="">
      <div @click="goBack" style="color: #696969;font-weight: 700;"> {{ $route.meta.name }}</div>
    </div>

    <div>
      <!-- <el-steps :active="active" finish-status="success">
        <el-step title="步骤 1" description="与加密卡服务器建立连接"></el-step>
        <el-step title="步骤 2" description="登录加密卡系统"></el-step>
      </el-steps> -->

      <!-- <el-col :span="10"> -->
      <!-- <div class="imgHome"> -->
      <!-- <div>
              <div class="bgImgMainOne">
              </div>
            </div> -->
      <!-- 
            <div v-show="!LinkState">
              <div v-show="distributionEntryFrom">
                <el-form class="leftFrom" ref="form" :model="form" :rules="loginRules">
                  <el-form-item>
                    <el-input style="border-radius:20px!important;" v-model="form.ip" placeholder="请输入接入地址"></el-input>
                  </el-form-item>
                  <el-form-item>
                    <el-input v-model.number="form.port" placeholder="请输入接入端口号"></el-input>
                  </el-form-item>
                </el-form>
                <el-button type="primary" @click="onSubmit">建立连接</el-button>
              </div>
              <div v-show="!distributionEntryFrom">
                <div type="danger" style="width: 100%;color: #F60A0A;">
                  <img style="margin-top: 0;top: 20px;left: 50px;" src="@renderer/assets/loginImg/warning.png" alt="">
                  链接失败,请重新设置连接后登录！
                </div>
                <el-button type="primary" @click="distributionEntry" style="margin-top: 24px; position: relative;width: 63px;height: 63px;">
                  <img style="margin-top: -24px;" src="@renderer/assets/loginImg/setting.png" alt="">
                  <div style="margin-top: 29px;left: -24px;"> 设置</div>
                </el-button>
              </div>
            </div> -->

      <!-- <div v-show="LinkState">
              <img class="" src="@renderer/assets/loginImg/linkSuccess.png" alt="">
            </div> -->
      <!-- </div> -->
      <!-- </el-col> -->

      <div class="imgHome">
        <div>
          <div class="bgImgMainTwoSuccess">
          </div>
          <div class="bgImgMainTwoLogin">
          </div>
        </div>
        <div>
          <el-form ref="formTwo" class="mainFrom" :model="formTwo" :rules="loginRulesTwo" @keyup.native.enter="onSubmitTwo">
            <el-form-item prop="passwd">
              <el-input style="border-radius:20px!important;" type="password" v-model="formTwo.passwd" placeholder="请输入密码"></el-input>
            </el-form-item>
            <img class="maibImgSize" src="@renderer/assets/loginImg/lock.png" alt="">
          </el-form>
          <el-button type='primary' @click="onSubmitTwo">登录</el-button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { postDmLogin } from '@renderer/api/encryptionCard.js'
export default {
  data() {
    const validateIp = (rule, value, callback) => {
      var t = /^((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.){3}(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])(?::(?:[0-9]|[1-9][0-9]{1,3}|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-5]))?$/
      if (value == '') {
        callback(new Error('ip地址不能为空'))
      } else if (!t.test(value)) {
        callback(new Error('请输入正确的IPV4地址'))
      } else {
        callback()
      }
    }
    const validatePasswd = (rule, value, callback) => {
      console.log(value)
      if (value == '') {
        callback(new Error('密码不能为空'))
      }
      else {
        callback()
      }
    }
    return {
      routerLayout: [],
      active: 0,
      LinkState: false,
      form: {
        ip: '',
        port: ''
      },
      formTwo: {
        passwd: "",
      },
      loginRulesTwo: {
        passwd: [{ required: true, trigger: 'blur', validator: validatePasswd, }],
      },
    };
  },
  created() {
  },
  methods: {
    goBack() {
      this.$router.push('/login')
    },
    async onSubmitTwo() {
      this.$refs.formTwo.validate(async valid => {
        if (valid) {
          try {
            await postDmLogin(this.formTwo)
            // if (this.active++ > 1) this.active = 0;
            localStorage.setItem('routingState', 'distribute')
            localStorage.setItem('distribute', 1)
            this.$router.push('/DistributionHomepage')
          } catch (err) {
            console.log(err)
          }
        }
      })

    }
  }
}
</script>

<style lang="less" scoped>
.grid {
  cursor: pointer;
  position: relative;
  img {
    position: relative;
  }
  div {
    position: absolute;
    top: 0px;
    left: 22px;
  }
}

.el-row {
  text-align: center;
}
.imgHome {
  padding: 50px;
  div {
    width: 100%;
    margin: 0 auto;
    // position: relative;
    // width: 85%;
    // margin: 0 auto;
    .bgImgMainTwoSuccess {
      width: 235px;
      height: 142px;
      background: url('@renderer/assets/loginImg/distributesuccess.png') no-repeat;
      background-size: 80%;
    }
    .bgImgMainTwoLogin {
      position: absolute;
      left: 50%;
      width: 177px;
      height: 24px;
      background: url('@renderer/assets/loginImg/welcome.png') no-repeat;
      background-size: 50%;
      transform: translate(-37%, 4px);
    }
    .mainFrom {
      width: 38%;
      position: relative;
      left: 48%;
      transform: translateX(-50%);
      margin-top: 40px;
      .maibImgSize {
        position: absolute;
        width: 15px;
        height: 15px;
        top: 8px;
        left: 15px;
      }
    }
    .el-button {
      width: 38%;
      position: relative;
      left: 48%;
      transform: translateX(-50%);
      margin-top: 24px;
      border-radius: 20px;
      background: #2978ff;
    }
  }
}

:deep(.el-input__wrapper) {
  border-radius: 95px;
  padding-left: 40px;
}
</style>
