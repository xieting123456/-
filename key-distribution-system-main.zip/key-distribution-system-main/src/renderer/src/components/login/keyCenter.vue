<template>
  <div class="login_container">
    <div class="grid">
      <img @click="goBack" style="margin-top: 5px;" src="@renderer/assets/loginImg/goBack.png" alt="">
      <div @click="goBack" style="color: #696969;font-weight: 700;"> {{ $route.meta.name }}</div>
    </div>

    <div>
      <el-steps :active="active" finish-status="success">
        <el-step title="步骤 1" description="与密钥中心服务器建立连接"></el-step>
        <el-step title="步骤 2" description="登录密钥中心系统"></el-step>
      </el-steps>
      <el-row>
        <el-col :span="12">
          <div class="imgHome">
            <div>
              <div class="bgImgMainOne">
                <!-- <img class="maibImgSize" src="@renderer/assets/loginImg/keyServer.png" alt=""> -->
              </div>
            </div>
            <div v-show="!LinkState">
              <el-form class="leftFrom" ref="form" :model="form" :rules="loginRules">
                <el-form-item prop="ip">
                  <el-input style="border-radius:20px!important;" v-model="form.ip" placeholder="请输入接入地址"></el-input>
                </el-form-item>
                <el-form-item prop="port">
                  <el-input v-model.number="form.port" placeholder="请输入接入端口号"></el-input>
                </el-form-item>
              </el-form>

              <el-button type="primary" @click="onSubmit">{{ interlinkage }}</el-button>
            </div>
            <div v-show="LinkState">
              <img class="" src="@renderer/assets/loginImg/linkSuccess.png" alt="">
            </div>
          </div>
        </el-col>
        <el-col :span="12">
          <div class="imgHome">
            <div>
              <div class="bgImgMainTwo" v-show="!LinkState">
                <!-- <img class="maibImgSize" src="@renderer/assets/loginImg/keyServer.png" alt=""> -->
              </div>
              <div class="bgImgMainTwoM" v-show="LinkState">
                <!-- <img class="maibImgSize" src="@renderer/assets/loginImg/keyServer.png" alt=""> -->
              </div>
            </div>
            <div>
              <el-form class="leftFrom" ref="formTwo" :model="formTwo" :rules="loginRulesTwo">
                <el-form-item prop="user">
                  <el-input style="border-radius:20px!important;" v-model="formTwo.user" placeholder="请输入用户名"></el-input>
                </el-form-item>
                <el-form-item prop="passwd">
                  <el-input v-model="formTwo.passwd" placeholder="请输入密码"></el-input>
                </el-form-item>
              </el-form>
              <el-button :type="LinkState==false?'info':'primary'" :disabled="LinkState==false" :style="LinkState==false?'background:#A8A8A8':'background:#2978FF'" @click="onSubmitTwo">登录</el-button>
              <div>
              </div>
            </div>
          </div>
        </el-col>

      </el-row>
    </div>
  </div>
</template>

<script>
import { loginKeyCenterServer, qkcLogin } from '@renderer/api/keyCenter.js'
export default {
  data() {
    const validateIp = (rule, value, callback) => {
      var t = /^((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.){3}(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])(?::(?:[0-9]|[1-9][0-9]{1,3}|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-5]))?$/
      if (value == '') {
        callback(new Error('ip地址不能为空'))
      } else if (!t.test(value)) {
        callback(new Error('请输入正确的IPV4地址'))
      } else {
        callback()
      }
    }
    const validatePort = (rule, value, callback) => {
      var poatTest = /^([1-9](\d{0,3}))$|^([1-5]\d{4})$|^(6[0-4]\d{3})$|^(65[0-4]\d{2})$|^(655[0-2]\d)$|^(6553[0-5])$/
      if (value == '') {
        callback(new Error('端口号不能为空'))
      } else if (!poatTest.test(value)) {
        callback(new Error('请输入1-65535端口号'))
      } else {
        callback()
      }
    }
    return {
      loginRules: {
        ip: [{ required: true, trigger: 'blur', validator: validateIp, }],
        port: [{ required: true, trigger: 'blur', validator: validatePort, }],
      },
      loginRulesTwo: {
        user: [{ required: true, trigger: 'blur', message: '用户名不能为空' }],
        passwd: [{ required: true, trigger: 'blur', message: '密码不能为空' }],
      },
      active: 0,
      LinkState: false,
      form: {
        ip: "",
        port: ''
      },
      interlinkage: '建立连接',
      formTwo: {
        user: "",
        passwd: ''
      },
      routerLayout: [],
    };
  },
  methods: {
    next() {
      if (this.active++ > 1) this.active = 0;
    },
    goBack() {
      this.$router.push('/login')
    },
    async onSubmit() {
      this.$refs.form.validate(async valid => {
        if (valid) {
          this.interlinkage = '正在建立链接...'
          try {
            await loginKeyCenterServer(this.form)
            this.LinkState = true
            if (this.active++ > 1) this.active = 0;
            this.interlinkage = '建立链接'
          } catch (err) {
            console.log(err)
            this.interlinkage = '建立链接'
          }
        }
      })
    },
    onSubmitTwo() {
      this.$refs.formTwo.validate(async valid => {
        if (valid) {
          try {
            await qkcLogin(this.formTwo)
            if (this.active++ > 1) this.active = 0;
            // 分配登录
            localStorage.setItem('routingState', 'allocation')
            localStorage.setItem('allocation', 1)
            this.$router.push('/KeyCenterHomePage')
          } catch (err) {
            console.log(err)
          }
        }
      })
    }
  }
}
</script>

<style lang="less" scoped>
.grid {
  cursor: pointer;
  position: relative;
  img {
    position: relative;
  }
  div {
    position: absolute;
    top: 0px;
    left: 22px;
  }
}

.el-row {
  text-align: center;
}
.imgHome {
  div {
    position: relative;
    width: 100%;
    img {
      position: relative;
      left: 10%;
      margin-top: 24px;
    }
    .bgImgMainOne {
      position: relative;
      left: 20%;
      width: 235px;
      height: 142px;
      background: url('@renderer/assets/loginImg/keyServer.png') no-repeat;
      background-size: 100%;
    }
    .bgImgMainTwo {
      position: relative;
      left: 27%;
      width: 235px;
      height: 142px;
      background: url('@renderer/assets/loginImg/matrix.png') no-repeat;
      background-size: 60%;
    }
    .bgImgMainTwoM {
      position: relative;
      left: 27%;
      width: 235px;
      height: 142px;
      background: url('@renderer/assets/loginImg/matrixSucss.png') no-repeat;
      background-size: 60%;
    }
  }
}
.el-button {
  font-size: 16px;
  width: 60%;
  height: 35px;
  line-height: 35px;
  border-radius: 20px;
  background: #2978ff;
}
.leftFrom {
  width: 100%;
  padding: 0 20% 0 20%;
}
:deep(.el-input__wrapper) {
  border-radius: 95px;
}
.el-steps {
  position: relative;
  left: 25%;
  top: -20px;
  width: 60%;
}
</style>
