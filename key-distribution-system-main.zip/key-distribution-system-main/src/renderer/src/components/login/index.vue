<template>
  <div class="login_container">
    <div>
      您好，请选择登录类型
    </div>
    <homeLog></homeLog>
  </div>
</template>

<script>
import homeLog from './homeLogin.vue'
//导入登录接口模块
export default {
  components: { homeLog },
  data() {
    return {
      dataInput: '',
      // 表单数据对象
      loginForm: {
        username: 'admin',
        password: '123456'
      },
      // 表单数据验证规则
      rules: {
        username: [
          { required: true, message: '请输入用户昵称:)', trigger: 'blur' },
          {
            min: 2,
            max: 25,
            message: '长度在 2 到 25 个字符',
            trigger: 'blur'
          }
        ],
        password: [
          { required: true, message: '请输入密码~~', trigger: 'blur' },
          { min: 6, max: 15, message: '长度在 6到 15 个字符', trigger: 'blur' }
        ]
      }
    }
  },
  created() {

  },
  methods: {
    //登录方法 再次校验-------------------------------
    async login() {
      this.$router.push('/')
    },
  }
}
</script>

<style lang="less" scoped>
</style>
