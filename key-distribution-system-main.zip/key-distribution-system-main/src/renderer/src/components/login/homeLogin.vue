<template>
  <div>
    <el-row class="">
      <el-col :span="12">
        <div class="imgHome">
          <div>
            <img src="@renderer/assets/loginImg/KeyCenterImg.png" alt="">
          </div>
          <div>
            <div class="bgImgMainOne">
              <!-- <img class="maibImgSize" src="@renderer/assets/loginImg/keyServer.png" alt=""> -->
            </div>
          </div>
          <div>
            <el-button type="primary" round @click="$router.push('/keyCenter')">密钥分配登录</el-button>
          </div>
        </div>
      </el-col>
      <el-col :span="12">
        <div class="imgHome">
          <div class="grid-content bg-purple">
            <div>
              <img src="@renderer/assets/loginImg/encryptionCardImg.png" alt="">
            </div>
            <div>
              <div class="bgImgMainTwo">

              </div>
            </div>
            <div>
              <el-button type="primary" round @click="$router.push('/encryptionCard')">密钥分发登录</el-button>
            </div>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
export default {
  data() {
    return {
      routerLayout: []
    }
  },
  created() {
  },
  methods: {

  }
}
</script>

<style lang="less" scoped>
.el-row {
  text-align: center;
  margin-top: 24px;
}
.imgHome {
  div {
    position: relative;
    width: 100%;
    img {
      position: relative;
      left: 20%;
      margin-top: 2px;
    }
    .bgImgMainOne {
      position: relative;
      left: 20%;
      width: 235px;
      height: 142px;
      background: url('@renderer/assets/loginImg/keyServer.png') no-repeat;
      background-size: 100%;
      margin-top: 24px;
    }
    .bgImgMainTwo {
      position: relative;
      left: 20%;
      width: 235px;
      height: 142px;
      background: url('@renderer/assets/loginImg/encryptionCardMain.png') no-repeat;
      background-size: 100%;
      margin-top: 24px;
    }
  }
}
.el-button {
  font-size: 16px;
  width: 252px;
  height: 38px;
  margin-top: 24px;
  background: #2978ff;
  margin-left: -26px;
}
</style>
