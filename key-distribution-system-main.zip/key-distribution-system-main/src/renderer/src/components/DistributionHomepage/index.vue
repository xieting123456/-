<template>
  <div>
    <el-row>
      <el-col :span="12">
        <div class="imgHome">
          <div>
            <div class="bgImgMainOne">
            </div>
            <div class="oKOrNo">
              <div v-show="statusOkOn" @click="showSetting">
                <img src="@renderer/assets/loginImg/ok.png" alt="">
                <span style="color: rgb(41, 120, 255);">已连接</span>
              </div>
              <div v-show="!statusOkOn" @click="showSetting">
                <img src="@renderer/assets/loginImg/no.png" alt="">
                <span class="colorSpan">未链接</span><br>
                <span class="colorSpan" style="margin-left: -57px;">(请点击，重新建立链接 !)</span>
              </div>
            </div>
          </div>
        </div>
      </el-col>

      <el-col :span="12">
        <div @click="rest" class="rest">刷新</div>
        <div class="twoRight">
          <div class="imgHomeTwo">
            <div class="grid-content bg-purple">
              <div>
                <el-row :gutter="20">
                  <el-col :span="18">
                    <div class="grid-content bg-purple">分发机：{{ cpu_id }}
                    </div>
                  </el-col>
                </el-row>
                <el-row :gutter="20">
                  <el-col :span="18">
                    <div>剩余空间 ：<span style="color: #2978FF;font-size: 24px;">{{ free_bytes_available }}</span></div>
                  </el-col>
                </el-row>
                <!-- 第一个 -->
                <el-row :gutter="20">
                  <el-col :span="18">
                    <div class="grid-content bg-purple"><el-progress color="#2362F4" :text-inside="true" :stroke-width="26" :percentage="schedule"></el-progress></div>
                  </el-col>
                </el-row>
                <!-- 第一个 -->
                <el-row :gutter="20">
                  <el-col :span="10">
                    <div class="grid-content bg-purple">已用空间：<span>{{used_size_bytes}}</span></div>
                  </el-col>
                  <el-col :span="9">
                    <div class="grid-content bg-purple">总空间：<span>{{all_bytes}}</span></div>
                  </el-col>
                </el-row>
                <!-- <div v-show="pictrue" class="bgImgMainTwo">
                </div>
                <div v-show="!pictrue" class="bgImgMainTwoFail">
                </div> -->
                <!-- <div style="margin-top: 14%;">加密卡 </div> -->
                <el-button type="primary" :style="!pictrue ? 'background: #D8D8D8;border-color: #D8D8D8' : 'background: #2978ff' " :disabled="!pictrue" @click="goRouter">查看任务</el-button>
              </div>
            </div>
          </div>
        </div>
      </el-col>
    </el-row>
    <el-dialog v-model="dialogVisible" title="链接设置" width="40%" :before-close="handleClose">
      <el-form ref="form" :model="form" :rules="loginRules">
        <el-form-item prop="ip">
          <el-input v-model="form.ip" placeholder="请输入接入地址"></el-input>
        </el-form-item>
        <el-form-item prop="port">
          <el-input v-model.number="form.port" placeholder="请输入接入端口号"></el-input>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button type="primary" @click="onSubmit"> 链接
          </el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script>
import { getEcStatus, getCup, getDisk, postEcAddr } from '@renderer/api/DistributionHomepage.js'
import { useCounterStore } from '@renderer/store/index.js'
import { storeToRefs } from 'pinia'
export default {
  name: 'log',
  data() {
    const validateIp = (rule, value, callback) => {
      var t = /^((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.){3}(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])(?::(?:[0-9]|[1-9][0-9]{1,3}|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-5]))?$/
      if (value == '') {
        callback(new Error('ip地址不能为空'))
      } else if (!t.test(value)) {
        callback(new Error('请输入正确的IPV4地址'))
      } else {
        callback()
      }
    }
    const validatePort = (rule, value, callback) => {
      var poatTest = /^([1-9](\d{0,3}))$|^([1-5]\d{4})$|^(6[0-4]\d{3})$|^(65[0-4]\d{2})$|^(655[0-2]\d)$|^(6553[0-5])$/
      if (value == '') {
        callback(new Error('端口号不能为空'))
      } else if (!poatTest.test(value)) {
        callback(new Error('请输入1-65535端口号'))
      } else {
        callback()
      }
    }
    return {
      loginRules: {
        ip: [{ required: true, trigger: 'blur', validator: validateIp, }],
        port: [{ required: true, trigger: 'blur', validator: validatePort, }],
      },
      form: {
        ip: "",
        port: ""
      },
      dialogVisible: false,
      input: '',
      success: false,
      fail: true,
      one: false,
      two: false,
      pictrue: true,
      routerLayout: [],
      cpu_id: '',
      free_bytes_available: '',
      used_size_bytes: '',
      all_bytes: '',
      resStaues: '',
      statusOkOn: false,
      schedule:0
    }
  },
  created() {
    this.getData()
    if (localStorage.getItem('link')) {

      this.gwtQkcStatus()
    } else {
      var linkFrom = {
        ip: "192.168.72.241",
        port: 20012
      }
      localStorage.setItem('link', JSON.stringify(linkFrom))

    }
  },
  methods: {
    rest() {
      this.gwtQkcStatus()
      this.getData()
    },
    async gwtQkcStatus() {
      try {
        const res = await getEcStatus(JSON.parse(localStorage.getItem('link')))
        if (res) {

          if (res.status !== 0) {
            this.statusOkOn = true
          } else {

            this.statusOkOn = false
          }
        }
      } catch (err) {

      }
    },
    async getData() {
      const resCpu = await getCup()
      const resDisk = await getDisk()
      this.cpu_id = resCpu.cpu_id
      this.free_bytes_available = this.byteConvert(Number(resDisk.free_bytes_available))
      this.used_size_bytes = this.byteConvert(Number(resDisk.used_size_bytes))
      this.all_bytes = this.byteConvert(Number(resDisk.free_bytes_available) + Number(resDisk.used_size_bytes))
      this.schedule = Number(resDisk.used_size_bytes) / (Number(resDisk.free_bytes_available) + Number(resDisk.used_size_bytes)) * 100
    },
    byteConvert(bytes) {
      const units = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
      let size = bytes;
      let unitIndex = 0;
      while (size >= 1024 && unitIndex < units.length - 1) {
        size /= 1024;
        unitIndex++;
      }
      // 保留两位小数，四舍五入
      size = Math.round(size * 100) / 100;
      return `${size} ${units[unitIndex]}`;
    },
    goRouter() {
      localStorage.setItem('distribute', 2)
      const routerLayout = useCounterStore();
      const { isAddRoutes } = storeToRefs(routerLayout);
      // 展示任务列表
      routerLayout.setLayOutRouter(true)
      this.$router.push('/DistributionLog')
    },
    showSetting() {
      this.dialogVisible = true
    },
    handleClose() {
      this.$refs.form.resetFields();
      this.dialogVisible = false
    },
    async onSubmit() {
      this.$refs.form.validate(async valid => {
        if (valid) {
          try {
            await postEcAddr(this.form)
            localStorage.setItem('link', JSON.stringify(this.form))
            this.dialogVisible = false
            this.gwtQkcStatus()
            this.getData()
          } catch (err) {
            console.log(err)
          }
        }
      })
    },
  }
}
</script>

<style lang="less" scoped>
.el-row {
  text-align: left;
  margin-bottom: 20px;
}
.twoRight {
  position: relative;
  left: 5%;
  top: 25%;
}
.imgHome {
  color: #303133;
  div {
    position: relative;
    width: 100%;
    img {
      position: relative;
      left: 45%;
    }
    span {
      position: relative;
      left: 44%;
      margin-top: 2px;
    }
    .bgImgMainOne {
      position: relative;
      left: 25%;
      margin-top: 18%;
      width: 198px;
      height: 158px;
      background: url('@renderer/assets/loginImg/ffjx.png') no-repeat;
      background-size: 100%;
    }
    .bgImgMainTwo {
      position: relative;
      left: 20%;
      top: 40px;
      width: 235px;
      height: 142px;
      background: url('@renderer/assets/loginImg/encryptionCardMain.png') no-repeat;
      background-size: 100%;
    }
    .bgImgMainTwoFail {
      position: relative;
      left: 20%;
      top: 40px;
      width: 235px;
      height: 142px;
      background: url('@renderer/assets/loginImg/failComputer.png') no-repeat;
      background-size: 100%;
    }
  }
}
.el-button {
  font-size: 16px;
  width: 252px;
  height: 38px;
  margin-top: 14px;
  background: #2978ff;
  border-radius: 20px;
}

::v-deep(.el-progress-bar__inner) {
  border-radius: 0 !important;
}
::v-deep(.el-progress-bar__outer) {
  border-radius: 0 !important;
}
::v-deep(.el-input__wrapper) {
  border-radius: 24px !important;
  width: 240px;
}
.right {
  position: relative;
  top: 16px;
}
.inputClass {
  margin-top: 24px;
  width: 252px !important;
  padding: 25px;
}
.bgImgMainMain {
  position: relative;
  left: 20%;
  width: 198px;
  height: 158px;
  background: url('@renderer/assets/loginImg/lianjie.png') no-repeat;
  background-size: 100%;
}
@keyframes testAni {
  0% {
    border-radius: 50px;
  }
  50% {
    border-radius: 0;
    transform: rotate(180deg);
    transform: translateX(10px);
  }
  100% {
    border-radius: 50px;
  }
}
.testBox {
  overflow: hidden;
  height: 100vh;
  padding: 0px 50px;
  box-sizing: border-box;
  .testCon {
    width: 150px;
    animation: testAni 3s ease-in-out infinite;
  }
}
@keyframes testConImg {
  0% {
    transform: rotate(0deg);
  }
  25% {
    transform: rotate(45deg);
  }
  50% {
    // border-radius: 0;
    transform: rotate(90deg);
  }
  100% {
    transform: rotate(180deg);
  }
}
.testBoxImg {
  overflow: hidden;
  box-sizing: border-box;
  .testConImg {
    animation: testConImg 3s ease-in-out infinite;
  }
}
.oKOrNo {
  img {
  }
  span {
    // color: #409eff;
  }
  // div {
  //   position: absolute;
  //   right: 16px;
  //   top: 6px;
  //   color: #409eff;
  // }
}
::v-deep(.el-dialog__footer) {
  text-align: center;
  box-sizing: border-box;
  padding-bottom: 24;
  margin-top: -50px;
  .el-button {
    width: 100%;
  }
}
.rest {
  cursor: pointer;
  float: right;
  margin: 20px 24px 24px 24px;
  color: #409eff;
}
.colorSpan {
  color: #ff0000f7;
}
</style>
