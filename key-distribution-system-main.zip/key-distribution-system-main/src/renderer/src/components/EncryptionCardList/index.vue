<template>
  <div class="distributionListtop">
    <el-form :inline="true" :model="formInline" class="demo-form-inline">
      <el-form-item label="卡组名称">
        <el-input v-model="formInline.gid"></el-input>
      </el-form-item>

      <el-form-item>
        <el-button type="primary" @click="onSubmit">查询</el-button>
      </el-form-item>

    </el-form>
  </div>
  <div class="list">
    <el-table :cell-style="{ 'text-align': 'center' }" :data="tableData" :header-cell-style="{background:'#E7ECF6','text-align': 'center'}" stripe style="width: 100%">
      <el-table-column label="序号" type="index" />
      <el-table-column prop="gid" label="加密卡组" />
      <el-table-column prop="first_did" label="主卡号" />
      <el-table-column prop="second_did" label="副卡号" />

      <el-table-column label="操作">
        <template #default="scope">
          <el-text type="primary" @click="distributeBtm('first',  scope.row)">主卡分配</el-text>
          <el-text class="ponit" type="primary" @click="distributeBtm('second',scope.row)">副卡分配</el-text>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page.sync="formInline.page_count" :page-size="formInline.size" layout="total, prev, pager, next" :total="totalAll">
    </el-pagination>

  </div>
</template>

<script >
import { getAllListBatch } from '@renderer/api/EncryptionCardList.js'
export default {
  name: 'log',
  data() {
    return {
      labelPosition: 'top',
      formInline: {
        gid: '',
        page_size: 4,
        page_count: 1
      },
      tableData: [],
      totalAll: 0
    }
  },
  created() {
    this.getAllList()

  },
  methods: {
    async getAllList() {
      try {
        const res = await getAllListBatch(this.formInline)
        if (res) {
          this.tableData = res.list
          this.totalAll = res.total_count
        }
      } catch (err) {
        console.log(err)
      }
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
    },
    handleCurrentChange(val) {
      this.formInline.page_count = val
      this.getAllList(this.formInline)
    },
    distributeBtm(a, row) {
      if (a == 'first') {
        var b = {
          gid: row.gid,
          ec: row.first_did,
          is_main: true
        }
        localStorage.setItem('DistributionTaskList', JSON.stringify(b))
      } else {
        var c = {
          gid: row.gid,
          ec: row.second_did,
          is_main: false
        }
        localStorage.setItem('DistributionTaskList', JSON.stringify(c))
      }
      this.$router.push('/DistributionTaskList')
    },
    onSubmit() {
      this.getAllList(this.formInline)
    },
    handleClose() {
      this.dialogVisible = false
    }
  },
}

</script >
<style lang="less" scoped>
.el-main {
  width: 100%;
  height: 100%;
  text-align: center;
  background: #efefef;
  padding: 0px !important;
}
.list {
  width: 100%;
  height: 380px;
  position: relative;
  .el-pagination {
    position: absolute;
    bottom: 0px;
    right: 0px;
    font-size: 12px;
  }
  .el-table {
    font-size: 12px;
  }
}
::v-deep(.el-pagination .el-select .el-input) {
  width: 80px;
  height: 28px;
}
::v-deep(.el-pagination .el-select) {
  font-size: 12px;
}
::v-deep(.el-pagination__editor.el-input) {
  width: 35px;
  height: 28px;
}
::v-deep(.el-pager li) {
  font-size: 12px;
}
::v-deep(.el-button--primary) {
  background: #2978ff;
}
::v-deep(.el-text):hover {
  cursor: pointer;
}
.el-dialog {
  ::v-deep(.el-input__wrapper) {
    border-radius: 20px;
    opacity: 1;
    background: #ffffff;
    box-sizing: border-box;
    border: 1px solid #d8d8d8;
    box-shadow: inset 0px 4px 11px -3px rgba(135, 166, 252, 0.5);
  }
}
.distributionListtop {
  padding: 20px 20px 0 20px;
  background: #fff;
}
::v-deep(.el-input) {
  font-size: 12px;
}
::v-deep(.el-form-item__label) {
  font-size: 12px;
}
::v-deep .el-table,
.el-table__expanded-cell {
  background-color: transparent !important;
}
::v-deep .el-table th {
  background-color: transparent !important;
}
::v-deep .el-table tr {
  background-color: transparent !important;
}
::v-deep .el-table--enable-row-transition .el-table__body td,
::v-deep .el-table .cell {
  background-color: transparent !important;
}
::v-deep .el-row {
  margin-bottom: 10px;
}
.colorLeft {
  color: #959393;
}
.colorright {
  color: #1a1a1a;
}
.ponit {
  margin-left: 10px;
}
</style>
