
<template>
  <div class="distributionListtop">
    <el-descriptions style="padding: 20px">
      <el-descriptions-item label="卡组名称：">{{  info.gid }}</el-descriptions-item>
      <el-descriptions-item label="卡组类型:">{{ info.ec }}</el-descriptions-item>
      <el-descriptions-item label="补充密钥量：">{{ info.needed }}</el-descriptions-item>
    </el-descriptions>
  </div>
  <div class="list">
    <el-table :cell-style="{ 'text-align': 'center' }" :data="tableData" :header-cell-style="{background:'#E7ECF6','text-align':'center'}" stripe style="width: 100%">
      <el-table-column type="index" label="序号" />
      <el-table-column prop="id" label="任务号" />
      <el-table-column prop="gid" label="加密卡组" />
      <el-table-column prop="batch_no" label="批次编号" />
      <el-table-column prop="name" label="大小">
        <template v-slot="scope">
          {{ ( min(scope.row.enc_needed, scope.row.enc_count+scope.row.enc_num)+min(scope.row.dec_needed, scope.row.dec_count+scope.row.dec_num))*0.125}}G
        </template>
      </el-table-column>
      <el-table-column prop="name" label="进度">
        <template v-slot="scope">
          <div>
            <div v-if=" (scope.row.enc_num+scope.row.dec_num)==0||(min(scope.row.enc_needed, scope.row.enc_count+scope.row.enc_num) + min(scope.row.dec_needed, scope.row.dec_count+scope.row.dec_num) ) ==0">
              0%
            </div>
            <div v-else>
              {{ (((scope.row.enc_num+scope.row.dec_num)/(min(scope.row.enc_needed, scope.row.enc_count+scope.row.enc_num) + min(scope.row.dec_needed, scope.row.dec_count+scope.row.dec_num) ))*100).toFixed(2)    }}%
            </div>
          </div>
        </template>
      </el-table-column>
      <el-table-column prop="name" label="已完成">
        <template v-slot="scope">
          {{ (scope.row.enc_num+scope.row.dec_num)*0.125 }}G
        </template>
      </el-table-column>

      <el-table-column type="expand" prop="name" label="操作">
        <template v-slot="scope">
          <div style="padding: 16px 1px 1px 367px;position: relative;background: linear-gradient(180deg, rgba(243,243,243,0.00) 0%, #CAF6FF 100%);">

            <el-row :gutter="20">
              <el-col :span="6">
                <div class="grid-content bg-purple"> 加密密钥文件:</div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content bg-purple">{{ scope.row.enc_num*0.125 }}G</div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content bg-purple"></div> <span v-if="scope.row.enc_num==0||min(scope.row.enc_needed, scope.row.enc_count+scope.row.enc_num)">
                  0%
                </span>
                <span v-else> {{scope.row.enc_num / min(scope.row.enc_needed, scope.row.enc_count+scope.row.enc_num)}} </span>
              </el-col>
              <el-col :span="6">
                <div class="grid-content bg-purple"> 分发成功文件数：{{ scope.row.enc_num }}</div>
              </el-col>
            </el-row>

            <el-row :gutter="20">
              <el-col :span="6">
                <div class="grid-content bg-purple">解密钥文件:</div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content bg-purple">{{ scope.row.dec_num*0.125 }}G</div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content bg-purple">
                  <span class=" bg-purple" v-if="scope.row.dec_num==0||min(scope.row.dec_needed, scope.row.dec_count+scope.row.dec_num)">
                    0%
                  </span>
                  <span class=" bg-purple" v-else> {{scope.row.dec_num / min(scope.row.dec_needed, scope.row.dec_count+scope.row.dec_num)}} </span>
                </div>
              </el-col>
              <el-col :span="6">
                <div class="grid-content bg-purple"> 分发成功文件数：{{ scope.row.dec_num }} </div>
              </el-col>
            </el-row>
          </div>
        </template>
      </el-table-column>
    </el-table>
    <!-- <el-dialog v-model="dialogVisible" title="分发详情" width="40%" :before-close="handleClose">
      <div style="border: 1px solid rgb(149 147 147 / 36%);border-radius: 4px;padding: 20px  0px 10px 20px;">
        <el-row :gutter="20">
          <el-col :span="10">
            <div class="colorLeft">
              加密卡ID：
            </div>
          </el-col>
          <el-col :span="10">
            <div class="colorright">
              oieuduweug
            </div>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="10">
            <div class="colorLeft">
              文件总量：
            </div>
          </el-col>
          <el-col :span="10">
            <div class="colorright">
              oieuduweug
            </div>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="10">
            <div class="colorLeft">
              文件总数：
            </div>
          </el-col>
          <el-col :span="10">
            <div class="colorright">
              oieuduweug
            </div>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="10">
            <div class="colorLeft">
              成功文件：
            </div>
          </el-col>
          <el-col :span="10">
            <div class="colorright">
              oieuduweug
            </div>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="10">
            <div class="colorLeft">
              失败文件：
            </div>
          </el-col>
          <el-col :span="10">
            <div class="colorright">
              oieuduweug
            </div>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="10">
            <div class="colorLeft">
              开始时间：
            </div>
          </el-col>
          <el-col :span="10">
            <div class="colorright">
              oieuduweug
            </div>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="10">
            <div class="colorLeft">
              结束时间：
            </div>
          </el-col>
          <el-col :span="10">
            <div class="colorright">
              oieuduweug
            </div>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="10">
            <div class="colorLeft">
              分发员：
            </div>
          </el-col>
          <el-col :span="10">
            <div class="colorright">
              oieuduweug
            </div>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="10">
            <div class="colorLeft">
              分发机ID：
            </div>
          </el-col>
          <el-col :span="10">
            <div class="colorright">
              oieuduweug
            </div>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="10">
            <div class="colorLeft">
              使用批次：
            </div>
          </el-col>
          <el-col :span="10">
            <div class="colorright">
              oieuduweug
            </div>
          </el-col>
        </el-row>
        <el-row :gutter="20">
          <el-col :span="10">
            <div class="colorLeft">
              密钥类型：
            </div>
          </el-col>
          <el-col :span="10">
            <div class="colorright">
              oieuduweug
            </div>
          </el-col>
        </el-row>

      </div>
    </el-dialog> -->
  </div>
</template>

<script >
import { getAllList, postEcNeeded } from '@renderer/api/DistributionList.js'
export default {
  name: 'log',
  data() {
    return {
      info: {
        gid: '(暂无)',
        ec: '(暂无)',
        needed: '(暂无)'
      },
      dialogVisible: false,
      labelPosition: 'top',
      formInline: {
        user: '',
        region: ''
      },
      formLabelAlign: {
        name: '',
        region: '',
        type: ''
      },
      tableData: [
      ],
      currentPage1: 4
    }
  },
  created() {
    this.getlist()
    this.getPostEcNeeded()
    // localStorage.setItem('allocation', 2)
  },
  methods: {
    min(a, b) {
      if (a < b) {
        return a
      } else {
        return b
      }
    },
    async getPostEcNeeded() {
      const res = await postEcNeeded()
      if (res) {
        if (res !== 0) {
          // dec 解密   补充密钥需要的解密文件数量
          // enc 加密   补充密钥需要的加密文件数量
          this.info.needed = (res.dec_needed + res.enc_needed) * 0.125 + 'G(' + res.dec_needed + '/' + res.enc_needed + ")"
        } else {
          this.info.needed = '认证后方可查看'
        }

      }
    },
    async getlist() {
      if (localStorage.getItem('DistributionTaskList')) {
        this.info.gid = JSON.parse(localStorage.getItem('DistributionTaskList')).gid
        if (JSON.parse(localStorage.getItem('DistributionTaskList')).is_main) {
          this.info.ec = "主"
        } else {
          this.info.ec = "副"
        }
      }
      const res = await getAllList(JSON.parse(localStorage.getItem('DistributionTaskList')))
      if (res) {
        this.tableData = res
        console.log(res)
      }
      if (this.tableData.length == 0) {
        this.info.gid = '(暂无)',
          this.info.ec = '(暂无)'
        this.info.needed = '(暂无)'
      }
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
    },
    distributeBtm() {
      this.dialogVisible = true
    },
    onSubmit() {
      console.log('submit!');
    },
    handleClose() {
      this.dialogVisible = false
    }
  },
}

</script >
<style lang="less" scoped>
.el-main {
  width: 100%;
  height: 100%;
  text-align: center;
  background: #efefef;
  padding: 0px !important;
}
.list {
  width: 100%;
  height: 380px;
  position: relative;
  top: 24px;
  .el-pagination {
    position: absolute;
    bottom: 20px;
    right: 20px;
    font-size: 12px;
  }
  .el-table {
    font-size: 12px;
  }
}
::v-deep(.el-pagination .el-select .el-input) {
  width: 80px;
  height: 28px;
}
::v-deep(.el-pagination .el-select) {
  font-size: 12px;
}
::v-deep(.el-pagination__editor.el-input) {
  width: 35px;
  height: 28px;
}
::v-deep(.el-pager li) {
  font-size: 12px;
}
::v-deep(.el-button--primary) {
  background: #2978ff;
}
::v-deep(.el-text):hover {
  cursor: pointer;
}
.el-dialog {
  ::v-deep(.el-input__wrapper) {
    border-radius: 20px;
    opacity: 1;
    background: #ffffff;
    box-sizing: border-box;
    border: 1px solid #d8d8d8;
    box-shadow: inset 0px 4px 11px -3px rgba(135, 166, 252, 0.5);
  }
}
.distributionListtop {
  background: #fff;
}
::v-deep(.el-input) {
  font-size: 12px;
}
::v-deep(.el-form-item__label) {
  font-size: 12px;
}
.bg-purple {
  color: #727a87;
  span {
    color: black;
  }
}

::v-deep .el-form-item {
  margin: 0 5px !important;
  // padding: 20px;
  // background-color: ;
}
::v-deep .el-table,
.el-table__expanded-cell {
  background-color: transparent !important;
}
::v-deep .el-table th {
  background-color: transparent !important;
}
::v-deep .el-table tr {
  background-color: transparent !important;
}
::v-deep .el-table--enable-row-transition .el-table__body td,
::v-deep .el-table .cell {
  background-color: transparent !important;
}
::v-deep .el-table .cell {
  background-color: transparent !important;
}
::v-deep .el-table .el-table__cell {
  padding: 0;
}
::v-deep .el-dialog__body {
  padding-top: 10px;
}
::v-deep .el-row {
  margin-bottom: 10px;
}
.colorLeft {
  color: #959393;
}
.colorright {
  color: #1a1a1a;
}
</style>
