<template>
  <div class="distributionListtop">
    <el-descriptions style="padding: 20px">
      <el-descriptions-item label="卡组名称：">{{ info.gid }}</el-descriptions-item>
      <el-descriptions-item label="卡组类型:">{{ info.ec }}</el-descriptions-item>

    </el-descriptions>
  </div>

  <div class="list">
    <el-table :cell-style="{ 'text-align': 'center' }" :data="tableData" :header-cell-style="{background:'#E7ECF6','text-align':'center'}" stripe style="width: 100%">
      <el-table-column type="index" label="序号" />
      <el-table-column prop="id" label="任务号" />
      <el-table-column prop="gid" label="加密卡组" />
      <el-table-column prop="batch_no" label="加密卡组号" />
      <el-table-column prop="name" width="200px" label="可分发至主卡密钥量（加/解）">
        <template v-slot="scope">
          <div>
            {{ ((scope.row.main_enc_count+scope.row.main_dec_count)*0.125).toFixed(2) }}G（{{ (scope.row.main_enc_count*0.125).toFixed(2) }}/{{(scope.row.main_dec_count*0.125).toFixed(2)}}）
          </div>
        </template>
      </el-table-column>

      <el-table-column prop="name" label="副卡同步状态">
        <template v-slot="scope">
          <div v-if="scope.row.dec_list+scope.row.enc_list == scope.row.main_dec + scope.row.main_enc">
          </div>
          <div v-else>
            <div v-show="scope.row.vice_dec_count+scope.row.vice_enc_count!==0">
              未同步
            </div>
            <div v-show="scope.row.vice_dec_count+scope.row.vice_enc_count==0">
              已同步
            </div>
          </div>
        </template>
      </el-table-column>

      <el-table-column label="操作">
        <template #default="scope">
          <el-text class="ponit" type="primary" @click="distributeBtm(scope.row)">分发</el-text>
        </template>
      </el-table-column>
    </el-table>
    <el-dialog v-model="dialogVisible" title="分发认证" width="40%" :before-close="handleClose">
      <el-form :label-position="labelPosition" label-width="80px" ref="form" :model="form" :rules="loginRules">
        <el-form-item label="请输入分发口令：" prop="passwd">
          <el-input type="password" v-model="form.passwd"></el-input>
        </el-form-item>
      </el-form>
      <template #footer>
        <span class="dialog-footer">
          <el-button @click="handleClose">取消</el-button>
          <el-button type="primary" @click="onSubmit">
            确认
          </el-button>
        </span>
      </template>
    </el-dialog>
  </div>
</template>

<script >
import { ElMessage } from 'element-plus'

import { getAllList, postEcVerify } from '@renderer/api/DistributionTaskList.js'
export default {
  name: 'log',
  data() {
    return {
      info: {
        gid: '(暂无)',
        ec: '(暂无)',
      },
      dialogVisible: false,
      labelPosition: 'top',
      loginRules: {
        passwd: [{ required: true, trigger: 'blur', message: '不能为空', }],
      },
      form: {
        passwd: "",
        did: '',
        batch_id: '',
        is_main: ''
      },
      tableData: [
      ],
      currentPage1: 4
    }
  },
  created() {
    this.getlist()
  },
  methods: {
    async getlist() {
      if (localStorage.getItem('DistributionTaskList')) {
        this.info.gid = JSON.parse(localStorage.getItem('DistributionTaskList')).gid
        if (JSON.parse(localStorage.getItem('DistributionTaskList')).is_main) {
          this.info.ec = "主"
        } else {
          this.info.ec = "副"
        }
      } else {
        console.log(localStorage.getItem('DistributionTaskList'), '我提交的参数')
      }
      const res = await getAllList(JSON.parse(localStorage.getItem('DistributionTaskList')))
      this.tableData = res
    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
    },
    distributeBtm(row) {
      if (JSON.parse(localStorage.getItem('DistributionTaskList'))) {
        this.form.is_main = JSON.parse(localStorage.getItem('DistributionTaskList')).is_main
        this.form.did = JSON.parse(localStorage.getItem('DistributionTaskList')).ec
        this.form.batch_id = row.id
      }
      this.dialogVisible = true
    },

    onSubmit(row) {
      console.log(row)
      this.$refs.form.validate(async valid => {
        if (valid) {
          try {
            await postEcVerify(this.form)
            this.dialogVisible = false
            ElMessage({
              message: '认证成功',
              type: 'success',
            })
            this.$refs.form.resetFields();
          } catch (err) {

          }
        }
      })
    },
    handleClose() {
      this.dialogVisible = false
      this.$refs.form.resetFields();
    }
  },
}

</script >
<style lang="less" scoped>
.el-main {
  width: 100%;
  height: 100%;
  text-align: center;
  background: #efefef;
  padding: 0px !important;
}
.list {
  width: 100%;
  height: 380px;
  position: relative;
  .el-pagination {
    position: absolute;
    bottom: 20px;
    right: 20px;
    font-size: 12px;
  }
  .el-table {
    font-size: 12px;
  }
}
::v-deep(.el-pagination .el-select .el-input) {
  width: 80px;
  height: 28px;
}
::v-deep(.el-pagination .el-select) {
  font-size: 12px;
}
::v-deep(.el-pagination__editor.el-input) {
  width: 35px;
  height: 28px;
}
::v-deep(.el-pager li) {
  font-size: 12px;
}
::v-deep(.el-button--primary) {
  background: #2978ff;
}
::v-deep(.el-text):hover {
  cursor: pointer;
}
.el-dialog {
  ::v-deep(.el-input__wrapper) {
    border-radius: 20px;
    opacity: 1;
    background: #ffffff;
    box-sizing: border-box;
    border: 1px solid #d8d8d8;
    box-shadow: inset 0px 4px 11px -3px rgba(135, 166, 252, 0.5);
  }
}
.distributionListtop {
  background: #fff;
}
::v-deep(.el-input) {
  font-size: 12px;
}
::v-deep(.el-form-item__label) {
  font-size: 12px;
}
.bg-purple {
  color: #727a87;
  span {
    color: black;
  }
}

::v-deep .el-form-item {
  margin: 0 5px !important;
  // padding: 20px;
  // background-color: ;
}
::v-deep .el-table,
.el-table__expanded-cell {
  background-color: transparent !important;
}
::v-deep .el-table th {
  background-color: transparent !important;
}
::v-deep .el-table tr {
  background-color: transparent !important;
}
::v-deep .el-table--enable-row-transition .el-table__body td,
::v-deep .el-table .cell {
  background-color: transparent !important;
}
::v-deep .el-table .cell {
  background-color: transparent !important;
}
::v-deep .el-table .el-table__cell {
  padding: 0;
}
::v-deep .el-dialog__body {
  padding-top: 10px;
}
::v-deep .el-row {
  margin-bottom: 10px;
}
.colorLeft {
  color: #959393;
}
.colorright {
  color: #1a1a1a;
}
</style>
