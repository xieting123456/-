<template>
  <div class="login_container">
    您好，请选择登录类型
  </div>
</template>


