<template>
  <div>
    <el-row class="">
      <el-col :span="12">
        <div class="imgHome">
          <div>
            <div class="bgImgMainOne">
            </div>
            <!-- 第一个 -->
            <el-row :gutter="20">
              <el-col :span="2">
                <div class="grid-content bg-purple"></div>
              </el-col>
              <el-col :span="18">
                <div class="grid-content bg-purple">分发机：{{ cpu_id }}
                  <div style="font-size: 14px;">（剩余空间 ：<span>{{ free_bytes_available }}</span>）</div>
                </div>
              </el-col>
            </el-row>
            <!-- 第一个 -->
            <el-row :gutter="20">
              <el-col :span="2">
                <div class="grid-content bg-purple"></div>
              </el-col>
              <el-col :span="18">
                <div class="grid-content bg-purple"><el-progress color="#2362F4" :text-inside="true" :stroke-width="26" :percentage="schedule"></el-progress></div>
              </el-col>
            </el-row>
            <!-- 第一个 -->
            <el-row :gutter="20">
              <el-col :span="1">
                <div class="grid-content bg-purple"></div>
              </el-col>
              <el-col :span="10">
                <div class="grid-content bg-purple">已用空间：<span>{{used_size_bytes}}</span></div>
              </el-col>
              <el-col :span="9">
                <div class="grid-content bg-purple">总空间：<span>{{all_bytes}}</span></div>
              </el-col>
            </el-row>
          </div>
        </div>
      </el-col>

      <div class="testBox">
        <div v-show="fail">
          <img src="@renderer/assets/loginImg/fail.png" alt="">
          <el-button style="width: 100px; font-size: 12px;height: 26px;" type="primary" round @click="goLogin">返回登录</el-button>
        </div>
        <div v-show="success">
          <img style="margin-left: 14px;" src="@renderer/assets/loginImg/success.png" alt="">
        </div>
        <div v-show="doing">
          <img src="@renderer/assets/loginImg/doing.png" alt="">
        </div>
        <div v-show="doinging" class="testCon">
          <img style="margin-left: 55px;" src="@renderer/assets/loginImg/lianjie.png" alt="">
          正在同步...
          <!-- <img style="margin-left: 14px;" src="@renderer/assets/loginImg/doinging.png" alt=""> -->
        </div>

        <!-- <div v-if="!result">
          <div v-show="doing">
            <img style="margin-left: 55px;" src="@renderer/assets/loginImg/lianjie.png" alt="">
            <div class="testCon" ref="loading">
              正在认证...
            </div>
          </div>

          <div v-show="!doing" class="testBoxImg">
            <div v-show="success">
              <img style="margin-left: 55px;" src="@renderer/assets/loginImg/lianjie.png" alt="">
              已认证
              <div class="testCon" ref="loading">
                正在同步...
              </div>
            </div>

            <div v-show="fail">
              <div>
                <img style="position: relative;width: 162px;top: 8px;z-index: 999;" src="@renderer/assets/loginImg/fail.png" alt="">
                <el-button style="width: 100px; font-size: 12px;height: 26px;" type="primary" round @click="goLogin">返回登录</el-button>
              </div>
            </div>
          </div>
        </div> -->

        <!-- <div v-show="result" class="testBoxImg">
          <div v-show="one">
            <img style="margin-left: 14px;" src="@renderer/assets/loginImg/lianjie.png" alt="">
            已认证...
            <div>
              同步成功...
            </div>
          </div>

          <div v-show="two">
            <img style="margin-left: 14px;" src="@renderer/assets/loginImg/lianjie.png" alt="">
            认证失败...
          </div>
        </div> -->
      </div>
      <el-col :span="12">
        <div class="imgHome">
          <div v-if="RightSide">
            <img v-show="!fail" style="margin-left: 14px;" src="@renderer/assets/loginImg/KeyCenter.png" alt="">
            <img v-show="fail" style="position: relative;left: 20%;margin-top: 21px;" src="@renderer/assets/loginImg/failComputer.png" alt="">
          </div>
          <div class="grid-content bg-purple right" v-if="RightSide">
            <div>
              登录成功，请输入认证口令
              <el-input class="inputClass" v-model.trim="input" placeholder="请输入内容"></el-input>
            </div>
            <div>
              <el-button type="primary" v-show="!fail" round @click="authentication">确认</el-button>
              <el-button type="primary" style="background: #93939387;border: 0;" v-show="fail" round @click="authentication">确认</el-button>
            </div>
          </div>
          <div class="imgHome" v-if="!RightSide">
            <div class="grid-content bg-purple">
              <div>
                <div v-show="pictrue" class="bgImgMainTwo">
                </div>
                <div v-show="!pictrue" class="bgImgMainTwoFail">
                </div>
                <div style="margin-top: 14%;">密钥中心</div>
                <el-button type="primary" :style="!pictrue ? 'background: #D8D8D8;border-color: #D8D8D8' : 'background: #2978ff' " :disabled="!pictrue" @click="onSubmit">任务列表</el-button>
              </div>
            </div>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import { useCounterStore } from '@renderer/store/index.js'
import { storeToRefs } from 'pinia'
import { getCup, getDisk, loginVerify, qkcStatus } from '@renderer/api/KeyCenterHomePage.js'
import { ecLogout, qkcLogout } from '@renderer/api/loginOut.js'
import { ElMessage } from 'element-plus'
export default {
  name: 'log',
  data() {
    return {
      a: null,
      doinging: false,
      doing: false,
      success: false,
      fail: false,
      input: '',
      RightSide: true,
      pictrue: true,
      routerLayout: [],
      cpu_id: '',
      free_bytes_available: '',
      used_size_bytes: '',
      all_bytes: '',
      resStaues: '',
      schedule: 0
    }
  },
  beforeDestroy() {
    clearInterval(this.a)
    this.a = null
  },
  created() {
    if (localStorage.getItem('allocation') == 2) {
      this.doinging = false,
        this.doing = true,
        this.success = false,
        this.fail = false
      this.pictrue = true
      this.RightSide = false
    }
    this.getData()
    if (localStorage.getItem('synchronization') == 1) {
      this.setIntervalget()
    }
  },
  methods: {
    async getData() {
      const resCpu = await getCup()
      const resDisk = await getDisk()
      this.cpu_id = resCpu.cpu_id
      this.free_bytes_available = this.byteConvert(Number(resDisk.free_bytes_available))
      this.used_size_bytes = this.byteConvert(Number(resDisk.used_size_bytes))
      this.all_bytes = this.byteConvert(Number(resDisk.free_bytes_available) + Number(resDisk.used_size_bytes))
      // 进度
      this.schedule = Number(resDisk.used_size_bytes) / (Number(resDisk.free_bytes_available) + Number(resDisk.used_size_bytes))*100
    },
    byteConvert(bytes) {
      const units = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
      let size = bytes;
      let unitIndex = 0;
      while (size >= 1024 && unitIndex < units.length - 1) {
        size /= 1024;
        unitIndex++;
      }
      // 保留两位小数，四舍五入
      size = Math.round(size * 100) / 100;
      return `${size} ${units[unitIndex]}`;
    },
    setIntervalget() {
      this.a = window.setInterval(async () => {
        // 3 表示认证通过了 1 建链 2 login
        const res = await qkcStatus()
        // res.status = 3
        this.resStaues = res.status
        // if (res) {
        //   if (res.status == 3) {
        // this.resStaues = await qkcStatus()
        if (this.resStaues >= 4) {
          localStorage.setItem('synchronization', 1)

          this.doinging = false,
            this.doing = true,
            this.success = false,
            this.fail = false
          this.pictrue = true
          this.close()
          this.RightSide = false
        } else {
          this.doinging = false,
            this.doing = false,
            this.success = false,
            this.fail = true
        }
      }, 1000)
    },
    close() {

      window.clearInterval(this.a)
      this.a = null
    },
    async authentication() {
      try {
        await loginVerify({ passwd: this.input })
        this.doinging = false,
          this.doing = false,
          this.success = true,
          this.fail = false

        this.setIntervalget()



      } catch (err) {
        this.RightSide = false
        this.doinging = false,
          this.doing = false,
          this.success = false,
          this.fail = true
        this.pictrue = false
      }
    },
    onSubmit() {
      localStorage.setItem('allocation', 2)
      const routerLayout = useCounterStore();
      const { isAddRoutes } = storeToRefs(routerLayout);
      // 展示任务列表
      routerLayout.setLayOutRouter(true)
      this.$router.push('/allocationList')
    },
    async goLogin() {
      try {
        if (localStorage.getItem("routingState")) {
          if (localStorage.getItem("routingState") == 'distribute') {
            // 退出加密卡
            await ecLogout()
            ElMessage({
              message: '加密卡已退出登录',
              type: 'success',
            })
          } else if (localStorage.getItem("routingState") == 'allocation') {
            // 退出密钥中心
            await qkcLogout()
            ElMessage({
              message: '密钥中心已退出登录',
              type: 'success',
            })
          }
        }
      } catch (err) {
      }
      localStorage.removeItem('distribute')
      localStorage.removeItem('routingState')
      localStorage.removeItem('allocation')
      localStorage.removeItem('synchronization')
      const routerLayout = useCounterStore();
      const { layOutRouter } = storeToRefs(routerLayout);
      routerLayout.setLayOutRouter()
      this.$router.push('/login')
    }
  }
}
</script>

<style lang="less" scoped>
.el-row {
  text-align: center;
  margin-top: 24px;
}
.imgHome {
  color: #303133;
  div {
    position: relative;
    width: 100%;
    img {
      position: relative;
      left: 30%;
      margin-top: 2px;
    }
    .bgImgMainOne {
      position: relative;
      left: 20%;
      width: 198px;
      height: 158px;
      background: url('@renderer/assets/loginImg/ffjx.png') no-repeat;
      background-size: 100%;
    }
    .bgImgMainTwo {
      position: relative;
      left: 24%;
      top: 40px;
      width: 235px;
      height: 142px;
      background: url('@renderer/assets/loginImg/keyServer.png') no-repeat;
      background-size: 100%;
    }
    .bgImgMainTwoFail {
      position: relative;
      left: 20%;
      top: 40px;
      width: 235px;
      height: 142px;
      background: url('@renderer/assets/loginImg/failComputer.png') no-repeat;
      background-size: 100%;
    }
  }
}
.el-button {
  font-size: 16px;
  width: 252px;
  height: 38px;
  margin-top: 24px;
  background: #2978ff;
  border-radius: 20px;
}

::v-deep(.el-progress-bar__inner) {
  border-radius: 0 !important;
}
::v-deep(.el-progress-bar__outer) {
  border-radius: 0 !important;
}
::v-deep(.el-input__wrapper) {
  border-radius: 24px !important;
  width: 240px;
}
.right {
  position: relative;
  top: 16px;
}
.inputClass {
  margin-top: 24px;
  width: 252px !important;
  margin-left: 5px;
  margin-right: 5px;
}
.bgImgMainMain {
  position: relative;
  left: 20%;
  width: 198px;
  height: 158px;
  background: url('@renderer/assets/loginImg/lianjie.png') no-repeat;
  background-size: 100%;
}
@keyframes testAni {
  0% {
    border-radius: 50px;
  }
  50% {
    border-radius: 0;
    transform: rotate(180deg);
    transform: translateX(10px);
  }
  100% {
    border-radius: 50px;
  }
}
.testBox {
  position: absolute;
  left: 48%;
  top: 44.5%;
  transform: translateX(-50%);
  width: 32%;
  overflow: hidden;
  height: 100vh;
  padding: 0px 50px;
  box-sizing: border-box;
  .testCon {
    width: 150px;
    animation: testAni 3s ease-in-out infinite;
  }
}
@keyframes testConImg {
  0% {
    transform: rotate(0deg);
  }
  25% {
    transform: rotate(45deg);
  }
  50% {
    // border-radius: 0;
    transform: rotate(90deg);
  }
  100% {
    transform: rotate(180deg);
  }
}
.testBoxImg {
  overflow: hidden;
  box-sizing: border-box;
  .testConImg {
    animation: testConImg 3s ease-in-out infinite;
  }
}
</style>
