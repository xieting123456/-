<template>
  <div class="list">
    <el-table :data="tableData" :cell-style="{ 'text-align': 'center' }" :header-cell-style="{background:'#E7ECF6','text-align': 'center'}" stripe style="width: 100%">
      <el-table-column type="index" label="序号" />
      <el-table-column prop="id" label="任务号" width="200" />
      <el-table-column prop="gid" label="加密卡组" width="200" />
      <el-table-column prop="batch_no" label="加密卡组号" />
      <el-table-column prop="enc_key_list" label="大小">
        <template v-slot="scope">
          <div>
            {{
            ((scope.row.dm_key_list.length+ scope.row.auth_key_list.length)*0.015625 + (scope.row.dec_key_list.length+scope.row.enc_key_list.length)*0.125).toFixed(2)
            }}GB
          </div>
        </template>
      </el-table-column>

      <el-table-column prop="name" label="任务进度">
        <template v-slot="scope">
          <div v-show="scope.row.status=1">
            完成
          </div>
        </template>
      </el-table-column>

      <el-table-column prop="status" label="状态">
        <template v-slot="scope">
          <div v-show="scope.row.status=1">
            完成
          </div>
          <div v-show="scope.row.status=0">
            进行中
          </div>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page.sync="currentPage1" :page-size="100" layout="total, prev, pager, next" :total="1000">
    </el-pagination>
  </div>
</template>

<script >
import { getAllList } from '@renderer/api/allocationList.js'
export default {
  name: 'log',
  data() {
    return {
      tableData: [],
      currentPage1: 4
    }
  },
  created() {
    localStorage.setItem('allocation', 2)
    this.getAllList()
  },
  methods: {
    async getAllList() {
      try {
        const res = await getAllList()
        this.tableData = res
      } catch (err) {

      }

    },
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
    }
  },
}

</script >
<style lang="less" scoped>
.el-main {
  width: 100%;
  height: 100%;
  text-align: center;
  background: #efefef;
  padding: 0px !important;
}
.list {
  width: 100%;
  height: 450px;
  position: relative;
  .el-pagination {
    position: absolute;
    bottom: 20px;
    right: 20px;
    font-size: 12px;
  }
  .el-table {
    font-size: 12px;
  }
}
::v-deep(.el-pagination .el-select .el-input) {
  width: 80px;
  height: 28px;
}
::v-deep(.el-pagination .el-select) {
  font-size: 12px;
}
::v-deep(.el-pagination__editor.el-input) {
  width: 35px;
  height: 28px;
}
::v-deep(.el-pager li) {
  font-size: 12px;
}
::v-deep .el-table,
.el-table__expanded-cell {
  background-color: transparent !important;
}
::v-deep .el-table th {
  background-color: transparent !important;
}
::v-deep .el-table tr {
  background-color: transparent !important;
}
::v-deep .el-table--enable-row-transition .el-table__body td,
::v-deep .el-table .cell {
  background-color: transparent !important;
}
</style>
