// // 控制拦截流程图
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import router from '../router/index'
const whiteList = ['/login']
import { useCounterStore } from '@renderer/store/index.js'
import { storeToRefs } from 'pinia'

router.beforeEach((to, from, next) => {
  // NProgress.start() // 开始加载进度条
  const token = localStorage.getItem('token_center')
  const routerLayout = useCounterStore()
  const { layOutRouter } = storeToRefs(routerLayout)

  // if (to.fullPath == '/login') {
  //   localStorage.removeItem('distribute')
  //   localStorage.removeItem('routingState')
  //   localStorage.removeItem('allocation')
  //   const routerLayout = useCounterStore()
  //   const { layOutRouter } = storeToRefs(routerLayout)
  //   routerLayout.setLayOutRouter()
  // }
  if (localStorage.getItem('routingState') && !routerLayout.isAddRoutes) {
    // 如果不是来着登录页面说明已经做了选择，并且没有添加过动态路由
    routerLayout.setLayOutRouter()
    next({ ...to, replace: true })
    // hack方法 确保addRoutes已完成
  } else {
    next()
  }
  NProgress.done()
  // if (token) {
  //   if (to.path === '/login') {
  //     next({
  //       path: '/'
  //     })
  //   } else {
  //     next()
  //   }
  //   NProgress.done() //进度条结束
  // } else {
  //   if (whiteList.indexOf(to.path) !== -1) {
  //     //进行遍历如果要去往的路由在白名单内
  //     next() // 就允许直接跳转
  //   } else {
  //     //否则，说明要去往的路由不在白名单内而且用户也没登录
  //     next(`/login?redirect=${to.path}`) // 那么，哦里给，滚回登录页去吧,或者只能留在登录页
  //     NProgress.done() //结束了，bor
  //   }
  // }
})
router.afterEach(() => {
  // 关闭进度条
  NProgress.done()
})
