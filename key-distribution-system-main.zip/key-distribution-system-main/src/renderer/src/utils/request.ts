import router from '@renderer/router'
import axios from 'axios'
import { ElMessage } from 'element-plus'

// const fs = require('fs')
// const path = require('path')
// fs.readFile(path.resolve('../../../../resources/config.js'), (d) => {
//   console.log(d)
// })
import api from '../../../../resources/config.js'
import { useCounterStore } from '@renderer/store/index.js'
// 创建axios实例
const request = axios.create({
  baseURL: api + '/dm/v1', // 所有的请求地址前缀部分(没有后端请求不用写)
  timeout: 80000, // 请求超时时间(毫秒)
  withCredentials: true // 异步请求携带cookie
  // headers: {
  // 设置后端需要的传参类型
  // 'Content-Type': 'application/json',
  // 'token': x-auth-token',//一开始就要token
  // 'X-Requested-With': 'XMLHttpRequest',
  // },
})

// request拦截器
request.interceptors.request.use(
  (config) => {
    // 如果你要去localStor获取token,(如果你有)
    // let token = localStorage.getItem("x-auth-token");
    // if (token) {
    //添加请求头
    //config.headers["Authorization"]="Bearer "+ token
    // }
    return config
  },
  (error) => {
    // 对请求错误做些什么
    Promise.reject(error)
  }
)

// response 拦截器
request.interceptors.response.use(
  (response) => {
    const { code, msg, data } = response.data
    if (code == 1) {
      return data
    } else if (code == 28) {
      router.push('/DistributionHomepage')
      // ElMessage.error(msg)
      // 捕捉错误
      return Promise.reject(new Error(msg))
    } else if (code == 30) {
      localStorage.removeItem('distribute')
      localStorage.removeItem('routingState')
      localStorage.removeItem('allocation')
      localStorage.removeItem('synchronization')
      const routerLayout = useCounterStore()
      // const { layOutRouter } = storeToRefs(routerLayout)
      routerLayout.setLayOutRouter()
      router.push('/login')
      ElMessage.error('链接断开，请重新登录')
      // 捕捉错误
      return Promise.reject(new Error(msg))
    } else if (code == 31) {
      localStorage.removeItem('distribute')
      localStorage.removeItem('routingState')
      localStorage.removeItem('allocation')
      localStorage.removeItem('synchronization')
      const routerLayout = useCounterStore()
      // const { layOutRouter } = storeToRefs(routerLayout)
      routerLayout.setLayOutRouter()
      router.push('/login')
      ElMessage.error('链接断开，请重新登录')
      // 捕捉错误
      return Promise.reject(new Error(msg))
    } else if (code == 5) {
      ElMessage.error('请求格式错误')
      // 捕捉错误
      return Promise.reject(new Error(msg))
    } else {
      // 后台会处理校验帐号的正确与否
      ElMessage.error(msg)
      // 捕捉错误
      return Promise.reject(new Error(msg))
    }
    // 对响应数据做点什么
    // return response.data
  },
  (error) => {
    if (error.response.status == 500) {
      ElMessage.error('请联系管理员，服务器地址有误！')
    } else {
      ElMessage.error(error.message)
    }
    // 对响应错误做点什么
    return Promise.reject(error)
  }
)
export default request
