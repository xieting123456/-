import request from '@renderer/utils/request'

// // post请求 ，没参数
// export const LogoutAPI = () => request.post('/api/users')

// export const loginAPI = (params) => request.get('/local/cpu', params)

// //  get请求，没参数，
export const getCup = () => request.get('/local/cpu')
export const getDisk = () => request.get('/local/disk')
export const loginVerify = (params) => request.post('/qkc/verify', params)
export const qkcStatus = (params) => request.get('/qkc/status', params)

// export const loginKeyCenterServer = (data) => request.post('/qkc/addr', data)
// export const qkcLogin = (data) => request.post('/qkc/login', data)
