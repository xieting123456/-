import request from '@renderer/utils/request'

export const getAllList = () => request.get('/ec/distribute/detail')
export const postEcNeeded = () => request.get('/ec/needed/cache')
