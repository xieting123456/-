import request from '@renderer/utils/request'

export const getAllList = () => request.get('/dm/batch')
