import request from '@renderer/utils/request'

export const ecAvailable = (data) => request.post('/dm/batch/ec/available', data)
export const getAllListBatch = (data) => request.post('/dm/ec/paging', data)
