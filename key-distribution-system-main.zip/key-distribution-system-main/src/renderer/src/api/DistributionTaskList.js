import request from '@renderer/utils/request'

export const getAllList = (params) => request.post('/ec/batch/detail', params)
export const postEcVerify = (params) => request.post('/ec/verify', params)
