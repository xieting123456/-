import request from '@renderer/utils/request'

// // post请求 ，没参数
// export const LogoutAPI = () => request.post('/api/users')

// export const loginAPI = (params) => request.get('/local/cpu', params)

// //  get请求，没参数，


export const ecLogout = (params) => request.post('/ec/logout', params)
export const qkcLogout = (params) => request.post('/qkc/logout', params)
