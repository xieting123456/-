import request from '@renderer/utils/request'

// export const getAllList = () => request.get('/dm/batch')
export const postDmLogin = (params) => request.post('/dm/login', params)

