
<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>
<script>
import { useCounterStore } from '@renderer/store/index.js'
import { storeToRefs } from 'pinia'
import { ElMessage } from 'element-plus'
import { ecLogout, qkcLogout } from '@renderer/api/loginOut.js'
export default ({
  data() {
    return {
      property: 'value',
    };
  },
  methods: {
  },
  mounted() {
    window.api.incrementNumber(async () => {
      try {
        if (localStorage.getItem("routingState")) {
          if (localStorage.getItem("routingState") == 'distribute') {
            // 退出加密卡
            await ecLogout()
          } else if (localStorage.getItem("routingState") == 'allocation') {
            // 退出密钥中心
            await qkcLogout()
          }
        }
      } catch (err) {

      }
      localStorage.removeItem('distribute')
      localStorage.removeItem('routingState')
      localStorage.removeItem('allocation')
      localStorage.removeItem('synchronization')
      const routerLayout = useCounterStore();
      const { layOutRouter } = storeToRefs(routerLayout);
      routerLayout.setLayOutRouter()
      this.$router.push('/login')
    })

    window.api.serverStart((a) => {
      console.log('后端服务器启动')
    })
    window.api.serverClose((a) => {
      console.log('后端服务器关闭')
    })
    window.api.showHomePage()
  }
})
</script>
<style lang="less">
</style>
