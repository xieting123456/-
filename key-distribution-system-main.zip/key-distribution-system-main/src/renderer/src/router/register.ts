import { RouteRecordRaw } from 'vue-router'

// 自动注册路由
// vite提供的方法，可以获取到路由信息：路由路径、路由模块遍历文件的方法-----获取布局路由
const layouts = import.meta.globEager('@renderer/layout/*.vue')
const views = import.meta.globEager('@renderer/components/**/*.vue')
function getRoutes() {
  // 空数组，用于存放结果
  const layoutRoutes = [] as RouteRecordRaw[]
  Object.entries(layouts).forEach(([file, module]: any) => {
    // 通过文件路径+模块，形成路由
    const route = getRouteByModule(file, module)
    // 将子路由也加进来
    route.children = getChildrenRoutes(route)
    layoutRoutes.push(route)
  })
  return layoutRoutes
}
// 遍历子路由
function getChildrenRoutes(layoutRoute: RouteRecordRaw): RouteRecordRaw[] {
  // 空数组，用于存放结果
  const children = [] as RouteRecordRaw[]
  Object.entries(views).forEach(([file, module]: any) => {
    // 找到是views路径的，加入到子路由中
    if (file.includes(`/src/components/${layoutRoute.name as string}`)) {
      const route = getRouteByModuleCjild(file, module)
      route.path = route.path.replace(/\//, '')
      children.push(route)
    }
  })
  return children
}
// 文件名转路由
function getRouteByModuleCjild(file: string, module: { [key: string]: any }) {
  // ../layouts/xxx.vue 从路径中拿到xxx
  const name = file.split('/').pop()?.split('.')[0]
  // 构造route
  const route = {
    path: `/${file.split('/')[file.split('/').length - 2]}-${name}`,
    name: `${file.split('/')[file.split('/').length - 2]}-${name}`,
    component: module.default
  }
  // 在页面中自定义路由优先于自动路由
  return Object.assign(route, module.default?.route)
}

// 文件名转路由
function getRouteByModule(file: string, module: { [key: string]: any }) {
  // ../layouts/xxx.vue 从路径中拿到xxx
  const name = file.split('/').pop()?.split('.')[0]
  // 构造route
  const route = {
    path: `/${name}`,
    name: name,
    component: module.default
  }
  // 在页面中自定义路由优先于自动路由
  return Object.assign(route, module.default?.route)
}

export default getRoutes()
