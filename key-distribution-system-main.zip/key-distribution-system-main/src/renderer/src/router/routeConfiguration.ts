import { RouteRecordRaw } from 'vue-router'

//Array<RouteRecordRaw>意思是ts的一个构造数组，传进去一个它的对象，
// 1. 配置路由
const routes = [
  {
    path: '/', // 默认路由 home页面
    name: 'layout',
    component: () => import('@renderer/layout/inde.vue'),
    redirect: '/login',
    meta: {
      name: '布局'
    },
    children: [
      {
        path: '/login',
        name: 'login',
        component: () => import('@renderer/components/login/index.vue'),
        meta: {
          name: '登录',
          hidden: false
        }
      },
      {
        path: '/keyCenter', // 默认路由 home页面
        name: 'keyCenter',
        component: () => import('@renderer/components/login/keyCenter.vue'),
        meta: {
          name: '密钥分配登录',
          hidden: true
        }
      },
      {
        path: '/encryptionCard', // 默认路由 home页面
        name: 'encryptionCard',
        component: () => import('@renderer/components/login/encryptionCard.vue'),
        meta: {
          name: '密钥分发登录 ',
          hidden: true
        }
      }
    ]
  }
] as RouteRecordRaw[]

export default routes
