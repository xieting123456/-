import { createRouter, createWebHashHistory } from 'vue-router'
import routes from '@renderer/router/routeConfiguration'
//Array<RouteRecordRaw>意思是ts的一个构造数组，传进去一个它的对象，
// 1. 配置路由

// 2.返回一个 router 实列，为函数，配置 history 模式
export const router = createRouter({
  history: createWebHashHistory(), //修改这里
  routes: [...routes],
  linkActiveClass: 'active'
})

// console.log(routes, layoutRoutes)
export function setUprouter(app) {
  app.use(router)
}

// 3.导出路由   去 main.ts 注册 router.ts
export default router
