import { RouteRecordRaw } from 'vue-router'

//Array<RouteRecordRaw>意思是ts的一个构造数组，传进去一个它的对象，
// 1. 配置路由
const reuse = [
  {
    path: '/', // 默认路由 home页面
    name: 'layout',
    component: () => import('@renderer/layout/inde.vue'),
    redirect: '/login',
    meta: {
      name: '布局'
    },
    children: [
      {
        path: '/login',
        name: 'login',
        component: () => import('@renderer/components/login/index.vue'),
        meta: {
          name: '登录',
          hidden: false
        }
      },
      // {
      //   path: '/KeyCenterHomePage', // 默认路由 home页面
      //   name: 'KeyCenterHomePage',
      //   // hidden: true,
      //   component: () => import('@renderer/components/KeyCenterHomePage/index.vue'),
      //   meta: {
      //     name: '分配主页',
      //     hidden: true
      //   }
      // },
      // {
      //   path: '/allocationList', // 默认路由 home页面
      //   name: 'allocationList',
      //   // hidden: true,
      //   component: () => import('@renderer/components/allocationList/index.vue'),
      //   meta: {
      //     name: '任务列表',
      //     hidden: true
      //   }
      // },
      {
        path: '/keyCenter', // 默认路由 home页面
        name: 'keyCenter',
        component: () => import('@renderer/components/login/keyCenter.vue'),
        meta: {
          name: '密钥分配登录',
          hidden: true
        }
      },
      // {
      //   path: '/DistributionHomepage', // 默认路由 home页面
      //   name: 'DistributionHomepage',
      //   // hidden: true,
      //   component: () => import('@renderer/components/DistributionHomepage/index.vue'),
      //   meta: {
      //     name: '分发主页',
      //     hidden: true
      //   }
      // },
      // {
      //   path: '/DistributionTaskList', // 默认路由 home页面
      //   name: 'DistributionTaskList',
      //   // hidden: true,
      //   component: () => import('@renderer/components/DistributionTaskList/index.vue'),
      //   meta: {
      //     name: '分发列表',
      //     hidden: true
      //   }
      // },
      // {
      //   path: '/DistributionTaskList', // 默认路由 home页面
      //   name: 'DistributionTaskList',
      //   // hidden: true,
      //   component: () => import('@renderer/components/DistributionTaskList/index.vue'),
      //   meta: {
      //     name: '任务列表',
      //     hidden: true
      //   }
      // },
      // {
      //   path: '/DistributionLog', // 默认路由 home页面
      //   name: 'DistributionLog',
      //   // hidden: true,
      //   component: () => import('@renderer/components/DistributionLog/index.vue'),
      //   meta: {
      //     name: '日志',
      //     hidden: true
      //   }
      // },

      {
        path: '/encryptionCard', // 默认路由 home页面
        name: 'encryptionCard',
        component: () => import('@renderer/components/404.vue'),
        meta: {
          name: '密钥分发登录 ',
          hidden: true
        }
      }
    ]
  },

  // {
  //   path: '/404',
  //   component: () => import('@/views/404'),
  //   hidden: true
  // }
] as RouteRecordRaw[]

export default reuse
