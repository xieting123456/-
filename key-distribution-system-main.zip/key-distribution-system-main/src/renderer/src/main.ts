import { createApp } from 'vue'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import '@renderer/assets/css/tailwind.css'
import '@renderer/assets/css/styles.less'
import App from '@renderer/App.vue'
import router, { setUprouter } from '@renderer/router/index'
import '@renderer/utils/promission'
import locale from 'element-plus/lib/locale/lang/zh-cn' //中文
//在app中引用

import { createPinia } from 'pinia'
const pinia = createPinia()

const app = createApp(App)
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component)
}
process.env['ELECTRON_DISABLE_SECURITY_WARNINGS'] = 'true'
async function mountApp() {
  setUprouter(app)
  app.use(ElementPlus, { locale })
  app.use(pinia)
  await router.isReady()
  // 等待路由加载完毕在挂载\
  app.mount('#app')
}
mountApp()
