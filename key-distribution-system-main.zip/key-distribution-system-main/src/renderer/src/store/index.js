import { defineStore } from 'pinia'
import routes from '../router/routeConfiguration.ts'
import router from '../router/index'
import _ from 'lodash'
export const useCounterStore = defineStore('counter', {
  // data里中的数据
  state: () => {
    return {
      token: '9999',
      user: '',
      layOutRouter: routes[0].children,
      isAddRoutes: false,
      allocation: [
        {
          path: '/KeyCenterHomePage', // 默认路由 home页面
          name: 'KeyCenterHomePage',
          // hidden: true,
          component: () => import('@renderer/components/KeyCenterHomePage/index.vue'),
          meta: {
            name: '分配主页',
            hidden: true
          }
        },
        {
          path: '/allocationList', // 默认路由 home页面
          name: 'allocationList',
          // hidden: true,
          component: () => import('@renderer/components/allocationList/index.vue'),
          meta: {
            name: '任务列表',
            hidden: true
          }
        }
      ],
      distribute: [
        {
          path: '/DistributionHomepage', // 默认路由 home页面
          name: 'DistributionHomepage',
          // hidden: true,
          component: () => import('@renderer/components/DistributionHomepage/index.vue'),
          meta: {
            name: '分发主页',
            hidden: true
          }
        },
        {
          path: '/DistributionLog', // 默认路由 home页面
          name: 'DistributionLog',
          // hidden: true,
          component: () => import('@renderer/components/EncryptionCardList/index.vue'),
          meta: {
            name: '加密卡列表',
            hidden: true
          }
        },
        {
          path: '/DistributionTaskList', // 默认路由 home页面
          name: 'DistributionTaskList',
          // hidden: true,
          component: () => import('@renderer/components/DistributionTaskList/index.vue'),
          meta: {
            name: '任务列表',
            hidden: true
          }
        },
        {
          path: '/DistributionList', // 默认路由 home页面
          name: 'DistributionList',
          // hidden: true,
          component: () => import('@renderer/components/DistributionList/index.vue'),
          meta: {
            name: '分发列表',
            hidden: true
          }
        }
      ]
    }
  },
  getters: {
    //通过getters对状态state进行获取
    settoken: (state) => state.token,
    getUser: (state) => state.user,
    setLayoutRouter: (state) => state.layOutRouter
  },
  actions: {
    setToken(isAuth) {
      this.token = isAuth //在pinia中this指代state
      console.log('我执行了')
    },
    setUser(user) {
      //解析的用户
      if (user) {
        this.user = user
      } else {
        this.user = {}
      }
    },
    setisAddRoutes() {
      this.setisAddRoutes = false
    },
    setLayOutRouter(layoutFrom) {
      if (!layoutFrom) {
        if (localStorage.getItem('routingState') == 'allocation') {
          // 分配路由
          router.addRoute('layout', this.allocation[0])
          router.addRoute('layout', this.allocation[1])
          if (localStorage.getItem('allocation') == 1) {
            // 首页显示
            this.allocation[0].meta.hidden = false
            this.allocation[1].meta.hidden = true
          } else if (localStorage.getItem('allocation') == 2) {
            // 首页显示
            this.allocation[0].meta.hidden = false
            this.allocation[1].meta.hidden = false
          }
          this.layOutRouter.unshift(...this.allocation)
          for (var i = 0; i < this.layOutRouter.length; i++) {
            if (this.layOutRouter[i].path == '/login') {
              this.layOutRouter[i].meta.hidden = true
            }
          }
          // 登录页隐藏
          this.isAddRoutes = true
        } else if (localStorage.getItem('routingState') == 'distribute') {
          // 分发路由
          router.addRoute('layout', this.distribute[0])
          router.addRoute('layout', this.distribute[1])
          router.addRoute('layout', this.distribute[2])
          router.addRoute('layout', this.distribute[3])
          if (localStorage.getItem('distribute') == 1) {
            // 首页显示
            this.distribute[0].meta.hidden = false
            this.distribute[1].meta.hidden = true
            this.distribute[2].meta.hidden = true
            this.distribute[3].meta.hidden = true
          } else if (localStorage.getItem('distribute') == 2) {
            // 首页显示
            this.distribute[0].meta.hidden = false
            this.distribute[1].meta.hidden = false
            this.distribute[2].meta.hidden = false
            this.distribute[3].meta.hidden = false
          }
          this.layOutRouter.unshift(...this.distribute)
          for (var i = 0; i < this.layOutRouter.length; i++) {
            if (this.layOutRouter[i].path == '/login') {
              this.layOutRouter[i].meta.hidden = true
            }
          }
          // 登录页隐藏
          this.isAddRoutes = true
        } else {
          // 退出登录
          // 退出登录删掉前面个
          // 展示login标题
          const res = this.layOutRouter
            .filter((item) => {
              return item.path !== '/KeyCenterHomePage'
            })
            .filter((item) => {
              return item.path !== '/allocationList'
            })
            .filter((item) => {
              return item.path !== '/DistributionHomepage'
            })
            .filter((item) => {
              return item.path !== '/DistributionList'
            })
            .filter((item) => {
              return item.path !== '/DistributionTaskList'
            })
            .filter((item) => {
              return item.path !== '/DistributionLog'
            })
          for (var x = 0; x < res.length; x++) {
            if (res[x].path == '/login') {
              res[x].meta.hidden = false
            }
          }
          this.layOutRouter = res
          this.isAddRoutes = false
        }
      } else {
        // 任务列表
        if (localStorage.getItem('routingState') == 'allocation') {
          this.allocation[1].meta.hidden = false
        } else if (localStorage.getItem('routingState') == 'distribute') {
          this.distribute[0].meta.hidden = false
          this.distribute[1].meta.hidden = false
          this.distribute[2].meta.hidden = false
          this.distribute[3].meta.hidden = false
        }
      }
      // this.layOutRouter.push(layoutRouter)
      // if (!layoutFrom) {
      //   // 分配 这个不存在需要重新配置路由
      //   if (localStorage.getItem('LoginSelection') == 'allocation') {
      //     router.addRoute('layout', this.allocation[0])
      //     router.addRoute('layout', this.allocation[1])
      //     this.layOutRouter.unshift(...this.allocation)
      //     this.isAddRoutes = true
      //   } else if (localStorage.getItem('LoginSelection') == 'distribute') {
      //     //   // 分发
      //     router.addRoute('layout', this.distribute[0])
      //     router.addRoute('layout', this.distribute[1])
      //     router.addRoute('layout', this.distribute[2])
      //     router.addRoute('layout', this.distribute[3])
      //     this.layOutRouter.unshift(...this.allocation)
      //     this.isAddRoutes = true
      //   } else {
      //     this.layOutRouter = reuse[0].children
      //   }
      // } else {
      //   //存在需要设置展示隐藏
      //   this.layOutRouter = layoutFrom
      // }
    },
    setisAddRoutes() {
      this.isAddRoutes = false
    },
    setDuanlian() {
      console.log(this.layOutRouter)
    },
    loginOut() {
      if (localStorage.getItem('allocation') == 1) {
        routes[0].children.shift()
      } else if (localStorage.getItem('allocation') == 2) {
        routes[0].children.shift()
        routes[0].children.shift()
      }
      this.layOutRouter = routes[0].children
      console.log(this.layOutRouter)
      localStorage.removeItem('distribute')
      localStorage.removeItem('routingState')
      localStorage.removeItem('allocation')
      localStorage.removeItem('synchronization')
    }
  }
})
