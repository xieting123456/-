var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// mock/index.js
var mock_exports = {};
__export(mock_exports, {
  default: () => mock_default
});
module.exports = __toCommonJS(mock_exports);
var import_mockjs = __toESM(require("mockjs"));
var userList = import_mockjs.default.mock({
  "data|100": [
    {
      name: "@cname",
      "id|+1": 1
    }
  ]
});
var userListData = [
  {
    method: "post",
    url: "/api/users",
    response: ({ body }) => {
      return {
        code: 200,
        msg: "success",
        data: userList
      };
    }
  }
];
var mock_default = userListData;
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsibW9jay9pbmRleC5qcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiY29uc3QgX19pbmplY3RlZF9maWxlbmFtZV9fID0gXCJGOlxcXFxlbGVjdHJvbi1TdHVkeVxcXFxlbGVjdHJvblxcXFxlbGVjdHJvbi1hcHBcXFxcbW9ja1xcXFxpbmRleC5qc1wiO2NvbnN0IF9faW5qZWN0ZWRfZGlybmFtZV9fID0gXCJGOlxcXFxlbGVjdHJvbi1TdHVkeVxcXFxlbGVjdHJvblxcXFxlbGVjdHJvbi1hcHBcXFxcbW9ja1wiO2NvbnN0IF9faW5qZWN0ZWRfaW1wb3J0X21ldGFfdXJsX18gPSBcImZpbGU6Ly8vRjovZWxlY3Ryb24tU3R1ZHkvZWxlY3Ryb24vZWxlY3Ryb24tYXBwL21vY2svaW5kZXguanNcIjtpbXBvcnQgbW9ja0pTIGZyb20gJ21vY2tqcydcclxuY29uc3QgdXNlckxpc3QgPSBtb2NrSlMubW9jayh7XHJcbiAgJ2RhdGF8MTAwJzogW1xyXG4gICAge1xyXG4gICAgICBuYW1lOiAnQGNuYW1lJyxcclxuICAgICAgJ2lkfCsxJzogMVxyXG4gICAgfVxyXG4gIF1cclxufSlcclxuXHJcbmNvbnN0IHVzZXJMaXN0RGF0YSA9IFtcclxuICB7XHJcbiAgICBtZXRob2Q6ICdwb3N0JyxcclxuICAgIHVybDogJy9hcGkvdXNlcnMnLFxyXG4gICAgcmVzcG9uc2U6ICh7IGJvZHkgfSkgPT4ge1xyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIGNvZGU6IDIwMCxcclxuICAgICAgICBtc2c6ICdzdWNjZXNzJyxcclxuICAgICAgICBkYXRhOiB1c2VyTGlzdFxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5dXHJcblxyXG5leHBvcnQgZGVmYXVsdCB1c2VyTGlzdERhdGFcclxuIl0sCiAgIm1hcHBpbmdzIjogIjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQWdSLG9CQUFtQjtBQUNuUyxJQUFNLFdBQVcsY0FBQUEsUUFBTyxLQUFLO0FBQUEsRUFDM0IsWUFBWTtBQUFBLElBQ1Y7QUFBQSxNQUNFLE1BQU07QUFBQSxNQUNOLFNBQVM7QUFBQSxJQUNYO0FBQUEsRUFDRjtBQUNGLENBQUM7QUFFRCxJQUFNLGVBQWU7QUFBQSxFQUNuQjtBQUFBLElBQ0UsUUFBUTtBQUFBLElBQ1IsS0FBSztBQUFBLElBQ0wsVUFBVSxDQUFDLEVBQUUsS0FBSyxNQUFNO0FBQ3RCLGFBQU87QUFBQSxRQUNMLE1BQU07QUFBQSxRQUNOLEtBQUs7QUFBQSxRQUNMLE1BQU07QUFBQSxNQUNSO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUVBLElBQU8sZUFBUTsiLAogICJuYW1lcyI6IFsibW9ja0pTIl0KfQo=
