import mockJS from 'mockjs'
// const userList = mockJS.mock({
//   'data|100': [
//     {
//       name: '@cname',
//       'id|+1': 1
//     }
//   ]
// })
const token = mockJS.mock({
  token: '谢二狗~~'
})

const userListData = [
  {
    method: 'post',
    url: '/api/users',
    response: ({ body }) => {
      return {
        code: 200,
        msg: 'success',
        data: token
      }
    }
  }
]

export default userListData
