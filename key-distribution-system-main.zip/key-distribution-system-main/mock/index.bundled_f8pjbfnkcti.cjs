var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// mock/index.js
var mock_exports = {};
__export(mock_exports, {
  default: () => mock_default
});
module.exports = __toCommonJS(mock_exports);
var import_mockjs = __toESM(require("mockjs"));
var token = import_mockjs.default.mock({
  token: "\u8C22\u4E8C\u72D7~~"
});
var userListData = [
  {
    method: "post",
    url: "/api/users",
    response: ({ body }) => {
      return {
        code: 200,
        msg: "success",
        data: token
      };
    }
  }
];
var mock_default = userListData;
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsibW9jay9pbmRleC5qcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiY29uc3QgX19pbmplY3RlZF9maWxlbmFtZV9fID0gXCJGOlxcXFxlbGVjdHJvbi1TdHVkeVxcXFxlbGVjdHJvblxcXFxLZXktRGlzdHJpYnV0aW9uLVN5c3RlbVxcXFxtb2NrXFxcXGluZGV4LmpzXCI7Y29uc3QgX19pbmplY3RlZF9kaXJuYW1lX18gPSBcIkY6XFxcXGVsZWN0cm9uLVN0dWR5XFxcXGVsZWN0cm9uXFxcXEtleS1EaXN0cmlidXRpb24tU3lzdGVtXFxcXG1vY2tcIjtjb25zdCBfX2luamVjdGVkX2ltcG9ydF9tZXRhX3VybF9fID0gXCJmaWxlOi8vL0Y6L2VsZWN0cm9uLVN0dWR5L2VsZWN0cm9uL0tleS1EaXN0cmlidXRpb24tU3lzdGVtL21vY2svaW5kZXguanNcIjtpbXBvcnQgbW9ja0pTIGZyb20gJ21vY2tqcydcclxuLy8gY29uc3QgdXNlckxpc3QgPSBtb2NrSlMubW9jayh7XHJcbi8vICAgJ2RhdGF8MTAwJzogW1xyXG4vLyAgICAge1xyXG4vLyAgICAgICBuYW1lOiAnQGNuYW1lJyxcclxuLy8gICAgICAgJ2lkfCsxJzogMVxyXG4vLyAgICAgfVxyXG4vLyAgIF1cclxuLy8gfSlcclxuY29uc3QgdG9rZW4gPSBtb2NrSlMubW9jayh7XHJcbiAgdG9rZW46ICdcdThDMjJcdTRFOENcdTcyRDd+fidcclxufSlcclxuXHJcbmNvbnN0IHVzZXJMaXN0RGF0YSA9IFtcclxuICB7XHJcbiAgICBtZXRob2Q6ICdwb3N0JyxcclxuICAgIHVybDogJy9hcGkvdXNlcnMnLFxyXG4gICAgcmVzcG9uc2U6ICh7IGJvZHkgfSkgPT4ge1xyXG4gICAgICByZXR1cm4ge1xyXG4gICAgICAgIGNvZGU6IDIwMCxcclxuICAgICAgICBtc2c6ICdzdWNjZXNzJyxcclxuICAgICAgICBkYXRhOiB0b2tlblxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5dXHJcblxyXG5leHBvcnQgZGVmYXVsdCB1c2VyTGlzdERhdGFcclxuIl0sCiAgIm1hcHBpbmdzIjogIjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQWlULG9CQUFtQjtBQVNwVSxJQUFNLFFBQVEsY0FBQUEsUUFBTyxLQUFLO0FBQUEsRUFDeEIsT0FBTztBQUNULENBQUM7QUFFRCxJQUFNLGVBQWU7QUFBQSxFQUNuQjtBQUFBLElBQ0UsUUFBUTtBQUFBLElBQ1IsS0FBSztBQUFBLElBQ0wsVUFBVSxDQUFDLEVBQUUsS0FBSyxNQUFNO0FBQ3RCLGFBQU87QUFBQSxRQUNMLE1BQU07QUFBQSxRQUNOLEtBQUs7QUFBQSxRQUNMLE1BQU07QUFBQSxNQUNSO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUVBLElBQU8sZUFBUTsiLAogICJuYW1lcyI6IFsibW9ja0pTIl0KfQo=
