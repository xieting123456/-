var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// mock/index.js
var mock_exports = {};
__export(mock_exports, {
  default: () => mock_default
});
module.exports = __toCommonJS(mock_exports);
var import_mockjs = __toESM(require("mockjs"));
var token = import_mockjs.default.mock({
  "data": [
    {
      token: "\u8C22\u4E8C\u72D7~~"
    }
  ]
});
var userListData = [
  {
    method: "post",
    url: "/api/users",
    response: ({ body }) => {
      return {
        code: 200,
        msg: "success",
        data: token
      };
    }
  }
];
var mock_default = userListData;
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsibW9jay9pbmRleC5qcyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiY29uc3QgX19pbmplY3RlZF9maWxlbmFtZV9fID0gXCJGOlxcXFxlbGVjdHJvbi1TdHVkeVxcXFxlbGVjdHJvblxcXFxlbGVjdHJvbi1hcHBcXFxcbW9ja1xcXFxpbmRleC5qc1wiO2NvbnN0IF9faW5qZWN0ZWRfZGlybmFtZV9fID0gXCJGOlxcXFxlbGVjdHJvbi1TdHVkeVxcXFxlbGVjdHJvblxcXFxlbGVjdHJvbi1hcHBcXFxcbW9ja1wiO2NvbnN0IF9faW5qZWN0ZWRfaW1wb3J0X21ldGFfdXJsX18gPSBcImZpbGU6Ly8vRjovZWxlY3Ryb24tU3R1ZHkvZWxlY3Ryb24vZWxlY3Ryb24tYXBwL21vY2svaW5kZXguanNcIjtpbXBvcnQgbW9ja0pTIGZyb20gJ21vY2tqcydcclxuLy8gY29uc3QgdXNlckxpc3QgPSBtb2NrSlMubW9jayh7XHJcbi8vICAgJ2RhdGF8MTAwJzogW1xyXG4vLyAgICAge1xyXG4vLyAgICAgICBuYW1lOiAnQGNuYW1lJyxcclxuLy8gICAgICAgJ2lkfCsxJzogMVxyXG4vLyAgICAgfVxyXG4vLyAgIF1cclxuLy8gfSlcclxuY29uc3QgdG9rZW4gPSBtb2NrSlMubW9jayh7XHJcbiAgJ2RhdGEnOiBbXHJcbiAgICB7XHJcbiAgICAgIHRva2VuOiAnXHU4QzIyXHU0RThDXHU3MkQ3fn4nXHJcbiAgICB9XHJcbiAgXVxyXG59KVxyXG5cclxuY29uc3QgdXNlckxpc3REYXRhID0gW1xyXG4gIHtcclxuICAgIG1ldGhvZDogJ3Bvc3QnLFxyXG4gICAgdXJsOiAnL2FwaS91c2VycycsXHJcbiAgICByZXNwb25zZTogKHsgYm9keSB9KSA9PiB7XHJcbiAgICAgIHJldHVybiB7XHJcbiAgICAgICAgY29kZTogMjAwLFxyXG4gICAgICAgIG1zZzogJ3N1Y2Nlc3MnLFxyXG4gICAgICAgIGRhdGE6IHRva2VuXHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbl1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IHVzZXJMaXN0RGF0YVxyXG4iXSwKICAibWFwcGluZ3MiOiAiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBZ1Isb0JBQW1CO0FBU25TLElBQU0sUUFBUSxjQUFBQSxRQUFPLEtBQUs7QUFBQSxFQUN4QixRQUFRO0FBQUEsSUFDTjtBQUFBLE1BQ0UsT0FBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQ0YsQ0FBQztBQUVELElBQU0sZUFBZTtBQUFBLEVBQ25CO0FBQUEsSUFDRSxRQUFRO0FBQUEsSUFDUixLQUFLO0FBQUEsSUFDTCxVQUFVLENBQUMsRUFBRSxLQUFLLE1BQU07QUFDdEIsYUFBTztBQUFBLFFBQ0wsTUFBTTtBQUFBLFFBQ04sS0FBSztBQUFBLFFBQ0wsTUFBTTtBQUFBLE1BQ1I7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBRUEsSUFBTyxlQUFROyIsCiAgIm5hbWVzIjogWyJtb2NrSlMiXQp9Cg==
